package project;

import api.palindrome.Palindrome;

public class MainClass {

	public static void main(String[] args) {
		System.out.println(Palindrome.palindrome("다시합창합시다"));
	}
}
