package day05_my;

import java.util.Scanner;

public class StudentManager {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		String[] nameList = new String[100];
		String[] genderList = new String[100];
		String[] emailList = new String[100];
		int[] birthList = new int[100];
		
		//현재 고객수가 몇명이 저장되었는지 알기위한 변수 count 선언
		int count=0;
		
		//index를 조정할 변수 선언
		int index = -1;
		boolean bool = false;
		
		info: while(true) {
			System.out.println("[info]- 고객수:"+count+"현재 위치:"+index);
			System.out.println("[메뉴]: 1.Insert, 2.Prev, 3.Next, 4.Current, 5.Update, 6.Delete, 7.Quit");
			System.out.print("메뉴 입력>");
			int menu = scan.nextInt();
			
			switch(menu) {
			
			case 1:
				System.out.println("=================고객 정보 입력을 시작합니다=================");
				/*
				 * 이름, 성별, 이메일, 출생년도를 입력받아서 각각 배열에 저장
				 * 사람수를 증가시킨다.
				 */				
				System.out.print("이름 입력>");
				nameList[count]=scan.next();
				System.out.print("성별 입력>");
				genderList[count]=scan.next();
				System.out.print("이메일 입력>");
				emailList[count]=scan.next();
				System.out.print("출생년도입력>");
				birthList[count]=scan.nextInt();
				count++;
				break;
			case 2:
				System.out.println("=================이전 고객 정보를 출력합니다=================");
				/*
				 * index가 0이라면 "이전 고객정보가 없습니다."
				 * 그렇지 않으면 index를 이용해서 이전 고객 정보를 출력하면 됩니다.
				 */
				if(index<=0) {
					System.out.println("이전 고객정보가 없습니다.");
				}else {
					index--;
					System.out.println(nameList[index]+" "+genderList[index]+" "+emailList[index]+" "+birthList[index]);
					bool=false;
				}
				break;
			case 3:
				System.out.println("=================다음 고객 정보를 출력합니다=================");
				/*
				 * 다음 고객정보를 출력할 수 없는 조건을 생각해서 "다음 고객정보가 없습니다."
				 * 그렇지 않으면  index를 이용해서 다음 1의 정보를 출력하면 됩니다.
				 */				
				if(index>=count-1) {
					System.out.println("다음 고객정보가 없습니다.");
				}else {
					index++;
					System.out.println(nameList[index]+" "+genderList[index]+" "+emailList[index]+" "+birthList[index]);
					bool=false;
				}
				break;
			case 4:
				System.out.println("=================현재 고객 정보를 출력합니다=================");
				/*
				 * 삭제되었을경우 현재정보가 삭제되었다는 메시지 출력
				 * 현재정보를 출력할 수있는 조건을 생각해서 현재 정보를 출력하면 됩니다.
				 * 그렇지 않으면 "현재 고객 정보가 없습니다." 
				 */
				if(bool) {
					System.out.println("현재 정보가 삭제되었습니다.");
				}else if(0<=index&&index<count) {
					System.out.println(nameList[index]+" "+genderList[index]+" "+emailList[index]+" "+birthList[index]);
				}
				else {
					System.out.println("현재고객 정보가 없습니다.");
				}					
				break;
			case 5:
				System.out.println("=================현재 고객 정보를 수정합니다=================");
				/*
				 * 현재 정보를 출력할 수 있는 조건을 생각해서
				 * 스캐너를 통해서 순서대로 이름, 성별, 이메일, 출생년도를 입력받아서 배열의 값을 수정하세요.
				 * 
				 * 그렇지 않으면 "수정할 데이터가 없습니다."
				 */
				if(0<=index&&index<count) {
					System.out.print("이름("+ nameList[index] +")수정>");
					nameList[index]=scan.next();
					System.out.print("성별("+ genderList[index] +")수정>");
					genderList[index]=scan.next();
					System.out.print("이메일("+ emailList[index] +")수정>");
					emailList[index]=scan.next();
					System.out.print("출생년도)"+ birthList[index] +"(수정>");
					birthList[index]=scan.nextInt();					
				}else 
					System.out.println("수정할 데이터가 없습니다.");				
				break;
			case 6:
				System.out.println("=================현재 고객 정보를 삭제합니다=================");
				/*
				 * 현재 정보를 삭제할 수 있는 조건을 생각해서
				 * 현재 index부터 ~~뒤에 있는 배열요소를 당겨와서 덮어 씌웁니다.
				 * 
				 * 그렇지 않으면 "삭제할 데이터가 존재하지 없습니다."를 출력하면 됩니다.
				 */
				if(0<=index&&index<count) {
					System.out.println(nameList[index]+"님 정보를 삭제합니다.");
					
					for(int i=index; i<count-1; i++) {
						nameList[i]=nameList[i+1];		
						genderList[i]=genderList[i+1];	
						emailList[i]=emailList[i+1];	
						birthList[i]=birthList[i+1];							
					}					
					count--;
					bool = true;
				}else
					System.out.println("삭제할 데이터가 없습니다.");
				
				break;
			case 7:
				System.out.println("프로그램을 종료합니다.");
				/*
				 * 무한루프 완전히 탈출
				 */
				break info;
				
			default:
				System.out.println("메뉴를 잘못입력했습니다.");
				
				break;
			}			
		}
		scan.close();
	}
}
