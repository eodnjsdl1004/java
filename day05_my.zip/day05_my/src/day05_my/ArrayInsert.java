package day05_my;

import java.util.Scanner;

public class ArrayInsert {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		String[] array = new String[100];
		int count=0; //입력 받은 개수
		
		System.out.println("먹고싶은 음식 입력하세요");
		System.out.println("입력을 중지하시려면 [그만]을 입력하세요.");

		
		
		while(true) {
			System.out.print(">");
			String menu = scan.nextLine();
			
			
			if(menu.equals("그만")) {
				System.out.println("입력 종료");
				break;
			}			
			
			array[count] = menu;
			count++;			
		}
		
		//입력 종료후, 출력 조건
		for(int i=0; i<count; i++) {
			System.out.print(array[i]+" ");
		}
		

//		int i=0;
//		while(true) {
//			System.out.print(">");
//			String menu = scan.nextLine();
//			if(menu.equals("그만")) {
//				System.out.println("입력종료");
//				break;
//			}
//			array[i] = menu;
//			i++;
//		}
//		System.out.print("[");
//		for(int j=0; j<i; j++) {
//			System.out.print(array[j]+" ");
//		}
//		System.out.println("]");
		scan.close();
	}
}
