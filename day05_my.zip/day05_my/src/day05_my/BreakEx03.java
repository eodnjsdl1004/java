package day05_my;

public class BreakEx03 {

	public static void main(String[] args) {
		
		boolean bool = false;
		
		start: for(char u = 'A'; u<='Z'; u++) { //반복문에 이름 지정가능
			for(char l='a'; l<='z'; l++) {
				
				System.out.println(u+"-"+l);
				if(l=='c') {
					bool=true;
					break start;				// 지정한 이름의 반복문까지 탈출함	
				}
				if(bool)
					break;
			}			
			
		}
	}
}
