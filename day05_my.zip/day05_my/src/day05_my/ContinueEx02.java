package day05_my;

import java.util.Scanner;

public class ContinueEx02 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수입력:");
		int num = scan.nextInt();
		
		int sum = 0;
		
		start:for(int i = 1; i<=num; i++) { 
			int cnt = 0; // 소수판별하기전에 count값을 초기
			
			for(int j = 1; j<=i; j++){ //1부터 i까지의 숫자 j를 활용
				if(i%j==0)  // i를 j로 나누었을때 나머지가 없다면  
					cnt++; // cnt 증가
				
				if(cnt>2)
				//	break;
					continue start;
			}
			if(cnt==2)  //cnt가 2일때 소수
				sum+=i; //i가 2부터 들어감
		}
		System.out.println(num+"까지 소수들의 합: "+sum);
		
		scan.close();
		
	}
}
