package day05_my;

import java.util.Arrays;
import java.util.Scanner;

public class RandomSeat {

	public static void main(String[] args) {
		
		/*
		 * 1. 사람수를 입력받을 수 있음
		 * 2. 입력받은 사람수만큼 랜덤값을 생성해서 배열에 중복되지 않게 집어 넣습니다.
		 * 
		 * 3. 해당 배열의 크기 만큼 ○으로 출력해주세요.
		 * 4. 스캐너를 통해서 랜덤으로 배정된 좌석을 선택할 수 있습니다.
		 * 5. 제대로 선택된 좌석이라면 자리번호를 공개하고, 제대로 선택되지않은 좌석이면 "경고문을 띄워 주세요."
		 * 
		 * 선택된 자리는 ●로 다시 표시해 주세요.
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.print("사람수 입력>");
		int pnum = sc.nextInt(); // 사람수 입력 ex)21
		int[] arr = new int[pnum]; // 사람수만큼의 배열 생성
		
						
			
			for(int i=0; i<arr.length; i++ ) { //1~입력받은수까지 순차적으로 입력				
				arr[i] = i+1;
				}	
			
			int temp=0;			
			for(int i=0; i<arr.length; i++) {
				int num = (int)(Math.random()*(pnum)); //0~(입력받은수-1) 까지의 랜덤값 생성 == 인덱스 번호
				temp=arr[num]; //랜덤값 인덱스번째 배열값을
				arr[num]=arr[i];
				arr[i]=temp; //자리 바꾸기
			}						
		
		System.out.println(Arrays.toString(arr)); //랜덤인지 확인
		
		System.out.println("자리를 선택 해주세요."); // 자리선택 화면
		for(int i=0; i<arr.length; i++) {
			System.out.print((i+1)+"○ ");
		}
		System.out.println();
		
		int[] num = new int[pnum]; // 입력받은 수만큼의 배열 생성
		boolean bool = true; //번호가 중첩되있는지 확인하기 위한 변수

		int i=0;		
		while(true) { 
				System.out.print("1부터"+pnum+"까지 숫자 선택");
				int seat = sc.nextInt(); //좌석번호 입력
				
				for(int j=0; j<num.length; j++) { // 좌석 번호가 배열에 들어가있는지 확인
					if(num[seat-1]==seat) { // seat-1번째 배열에 해당 좌석 번호가 들어가 있다면
						System.out.println("다른 번호를 선택해주세요.");
						bool=false; //중첩되있으면 false
						break;						
					}else if(num[j]==0) { //좌석번호가 안들어있고 나머지 배열값이 전부 0이라면
						num[seat-1] = seat; //좌석 번호 -1 인덱스번째에 seat(좌석번호)를 대입
						bool= true; //새로 들어오는 거라면 true
						break;
					}					
				}
				
				if(bool) { // 중복되지 않았다면
					System.out.println("해당숫자에 해당하는 자리번호: "+arr[seat-1]+"번 자리로 가세요.");
					for(int j=0; j<arr.length; j++) { //0~ 사람수 배열크기만큼
						if(num[j]!=0) //array[]는 좌석값이므로, 좌석값이 입력되있다면
							System.out.print((j+1)+"●"); // 색칠
						else
							System.out.print((j+1)+"○ ");	// 아니라면 빈 동그라미				
					}
					System.out.println();					
					i++; //중복안되서 출력할때만 i값이 증가
				}										
					if(i==pnum) { //사람수만큼 i가 증가한다면 탈출
						break;
				}												
			}
		sc.close();
	}
}
