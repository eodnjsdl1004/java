package day05_my;

import java.util.Scanner;

public class Arraykakao {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String[] arr = new String[100];
		
		int i=0;
		while(true) {
			System.out.print("입력할 카카오 친구>");
			String input = sc.next();
			
			if(input.equals("그만")) {
				System.out.println("입력종료");
				break;
			}
			
			arr[i]=input;
			System.out.println(arr[i]+"입력 성공");
			System.out.println("------------------");
			i++;			
		}
		System.out.println(i+"명의 카카오 친구들이 입력되었습니다.");
		sc.close();
	}
}
