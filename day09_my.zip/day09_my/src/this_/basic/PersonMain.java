package this_.basic;

public class PersonMain {

	public static void main(String[] args) {
		
		Person p1 = new Person("홍길자",20);
		Person p2 = new Person("홍길동");
		Person p3 = new Person();
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		Student s = new Student("팽귄",13,"321321");
		System.out.println(s.info());
		
		Teacher t = new Teacher("유미",3,"낚시");
		System.out.println(t.info());
		
		Employee e = new Employee("돌쇠",40,"전산");	
		System.out.println(e.info());		
		
	}	
}
