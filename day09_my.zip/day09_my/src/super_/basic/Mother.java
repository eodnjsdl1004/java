package super_.basic;

public class Mother extends Person{

	//생략되어있음
	Mother(){
		super();
	}
}
