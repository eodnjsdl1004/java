package super_.basic2;

public class MainClass {

	public static void main(String[] args) {
		Child child = new Child("황xx","이xx","황대원");
		
		child.info();
	}
}
