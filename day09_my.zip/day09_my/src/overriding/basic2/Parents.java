package overriding.basic2;

public class Parents {
	
	void method1() {
		System.out.println("부모메서드 1번");
	}
	void method2() {
		System.out.println("부모메서드 2번");
	}

}
