package overriding.basic2;

public class Child extends Parents{

	void method2() {
		System.out.println("자식의 재정의된 메서드 2번");
	}
	void method3() {
		System.out.println("자식의 메서드 3번");
	}
}
