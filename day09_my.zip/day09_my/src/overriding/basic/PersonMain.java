package overriding.basic;

public class PersonMain {

	public static void main(String[] args) {
		
		Student s = new Student();
		s.name="팽귄";
		s.age=13;
		s.studentId="321321";
		System.out.println(s.info());
		
		Teacher t = new Teacher();
		t.name="유미";
		t.age=3;
		t.subject="낚시";
		System.out.println(t.info());
		
		Employee e = new Employee();			
		e.name="돌쇠";
		e.age=40;		
		e.department="전산";
		System.out.println(e.info());
	}	
}
