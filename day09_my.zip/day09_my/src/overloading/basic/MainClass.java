package overloading.basic;

public class MainClass {

	public static void main(String[] args) {
		
		Basic b = new Basic();
		
		b.input(1);
		b.input("하핳");
		b.input(3.14, 7);
		b.input(7, 3.14);
		b.input("야", "호");
		b.input('Y', 4, 4.44);		
	}
}
