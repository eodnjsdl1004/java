package overloading.basic;

public class Basic {
	
	/*
	 * 오버로딩- 같은 이름의 메서드를 여러개 생성하는 것
	 * 		      (상속과 관계없음)
	 * 
	 * 규칙: 이름이 같아야한다.
	 * 		반환유형이 상관없다.(같아도 되고 달라도 됨)
	 * 
	 * 		매개변수 타입이 달라야한다.
	 * 		매개변수 종류가 달라야한다.
	 * 		매개변수 순서가 달라야한다.
	 * 		완전히 동일하지 않으면 됨.
	 */
	
	void input(int a) {
		System.out.println("정수 1개가 입력됨");
	}
	
	//반환유형이 달라도 매개변수와 이름이 같기 때문에
//	int input(int a) { // 오버로딩이 아니고 중복, 반환유형은 관계없음
//		return a;
//	}
	
	void input(String s) {
		System.out.println("문자열 1개가 입력됨");
	}

	void input(int a, double b) {
		System.out.println("정수 1개, 실수1개가 입력됨");
	}
	
	void input(double b, int a) {
		System.out.println("실수1개, 정수 1개가 입력됨");
	}
	void input(String a, String b) {
		System.out.println("문자열 2개가 입력됨");
	}
	void input(char a, int b, double c) {
		System.out.println("문자1개, 정수 1개, 실수 1개 입력됨");
	}
}
