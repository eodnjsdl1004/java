package test_my;

import java.util.Scanner;

public class Test02 {

	public static void main(String[] args) {
		//2. 정수를 입력받아서 해당 숫자까지 모든 소수들의 합
		//ex)5를 입력받으면 2,3,5를 더한 10이 나오도록 프로그램
		
		int sum = 0;
		int cnt=0;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("정수입력:");
		int num = scan.nextInt();
		
		for(int i = 2; i<=num; i++) { //소수는 2부터 시작이라서 i는 2부터 num까지
			for(int j = 2; j<=i; j++){ //2부터 i까지의 숫자 j를 활용
				if(i%j==0) { // i가 j로 나누었을때 나머지가 없다면  
					cnt++; // cnt 증가
				}				
			}
			if(cnt==1) { //cnt가 1일때는 소수
				sum+=i;
			}
			cnt=0;
		}
		System.out.println(sum);
	}
}
