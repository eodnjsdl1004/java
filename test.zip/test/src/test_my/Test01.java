package test_my;

public class Test01 {

	public static void main(String[] args) {
		//1. 100개의 크기를 갖는 int 배열에 2의 배수를 순서대로 저장
		int[] arr = new int[100];
		
		for(int i=0; i<=99; i++) {
			
			arr[i] = 2*(i+1);
			System.out.println(arr[i]);
		}
		
	}
}
