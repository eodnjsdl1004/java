package test_my;

import java.util.Scanner;

public class Test03 {

	public static void main(String[] args) {
		/*
		 * Scanner를 통해 2개의 정수를 입려갇습니다.
		 * 입력받은 정수값이 단순히 정수면 2개를 출력하고 종료.
		 * 
		 * 입력받은 값이 예외를 발생시키는 값이라면 "정수를 입력하세요"를 출력하여 
		 * 다시 처음부터 정수를 입력받게 하면 됩니다.
		 * 
		 * 정상 종료가 되면 "프로그램 정상종료"라고 합니다.
		 */
		
		
		while(true) {
			try {
			InputNum();
			
			break;
				
			} catch (Exception e) {
				System.out.println("정수를 입력하세요.");
				InputNum();
				break;
			}
		}
	}
	
	public static void InputNum() {
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("정수입력:");	
		int n = sc.nextInt();
		System.out.println("정수입력:");	
		int m = sc.nextInt();
		

		System.out.println(n+" "+m);
		System.out.println("프로그램 정상종료");
	}
	
}
