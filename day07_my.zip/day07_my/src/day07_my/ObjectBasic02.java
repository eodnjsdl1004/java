package day07_my;

public class ObjectBasic02 {

	public static void main(String[] args) {
		Calculator cal = new Calculator();
		
		System.out.println("----------1번 계산기----------");
		System.out.println(cal.add(1));
		System.out.println(cal.add(2));
		System.out.println(cal.add(3));
		
		Calculator cal1 = new Calculator();
		
		System.out.println("----------1번 계산기----------");
		System.out.println(cal1.add(10));
		System.out.println(cal1.add(20));
		System.out.println(cal1.add(30));
		
	}
}
