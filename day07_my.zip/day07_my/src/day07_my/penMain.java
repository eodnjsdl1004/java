package day07_my;

public class penMain {

	public static void main(String[] args) {
	
		//Pen의 기능 속성을 쓰려면 설계용 클래스를 개체로 생성해야합니다.
		//객체의 기능과 속성을 사용할 때는 창조연산자 .을 사용합니다.
		Pen black = new Pen();
		
		black.ink="검정";
		black.price = 500;
		black.company ="모나미";
		
		black.writer();		
		
		Pen red = new Pen();
		
		red.ink="빨강";
		red.price=1000;
		red.company="하이테크";
		
		red.writer();
		
		black.info();
		red.info();
	}
}
