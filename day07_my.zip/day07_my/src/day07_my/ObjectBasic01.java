package day07_my;

public class ObjectBasic01 {

	public static void main(String[] args) {
		//기존 사용하던 방법
		
		
		System.out.println("----------1번 계산기----------");
		System.out.println(add(1));
		System.out.println(add(2));
		System.out.println(add(3));
		
		System.out.println("----------2번 계산기----------");
		System.out.println(add1(10));
		System.out.println(add1(20));
		System.out.println(add1(30));
	}
	
	//1번 메서드
	static int result=0;	
	static int add(int n) {
		return result+=n;
	}
	
	//2번 메서드
		static int result1=0;	
		static int add1(int n) {
			return result1+=n;
		}
	
}
