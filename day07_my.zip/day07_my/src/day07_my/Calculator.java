package day07_my;

public class Calculator {
	int result=0;	
	int add(int n) {
		return result+=n;
	}
}
