package day07_my;

public class Variable {

	//멤버변수: 초기화 하지 않으면 자동으로 초기화 됨, 값이 누적됨
	int a;
	//a=10; 값을 바꾸고 싶다면 메서드안에서 사용해야함
	
	//메서드 선언.
	void printNumber(int c) { //매개변수는 초기화를 하지 않아도 되는 지역변수
		//지역변수: 초기화를 해야만 쓸수 있음
		int b=1;
		System.out.println("멤버:"+a);
		System.out.println("지역:"+b);		
		System.out.println("매개:"+c);
	}	
	
}
