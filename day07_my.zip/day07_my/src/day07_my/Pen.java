package day07_my;

//설계도 클래스는 메인메서드가 없어요.
public class Pen {

	//클래스 안에 속성을 나타내는 것을 멤버변수(필드)라고 부릅니다.
	
	String ink;
	int price;
	String company;
	
	//클래스 안에 기능을 나타내는 것을 매서드라고 부릅니다.
	void writer(){
		System.out.println(ink+"색상 글씨를 씁니다.");
	}	
	void info() {
		System.out.println("------팬의 정보------");
		System.out.println("색상:"+ink);
		System.out.println("가격:"+price);
		System.out.println("제조사:"+company);
	}
	
}
