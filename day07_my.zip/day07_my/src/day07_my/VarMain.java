package day07_my;

public class VarMain {

	public static void main(String[] args) {
		Variable var = new Variable();
				
		var.printNumber(10);
		var.a=10;
		System.out.println("--------------");
		var.printNumber(20);
	}
}
