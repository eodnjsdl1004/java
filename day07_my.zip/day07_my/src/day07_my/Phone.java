package day07_my;

public class Phone {

	String model;
	int price;
	String color;
	
	//생성자: 클래스이름과 대/소문자까지 동일
	//반환유형은 없음
	Phone(){	
		model="큐리텔";
		price=200000;
		color="검정";
	}
	//생성자는 중복해서 여러개 선언할수 있습니다.
	//단, 매개변수의 종류, 개수가 달라야 합니다.
	Phone(String pColor){	
		model="애니콜";
		price=200000;
		color=pColor;
	}
	Phone(String pColor,int pPrice){
		model="가로본능";
		price=pPrice;
		color=pColor;
	}
	
	Phone(String pColor,String pModel){			
		model=pModel;
		price=150000;
		color=pColor;
	}
	
	Phone(String pColor,int pPrice,String pModel){			
		model=pModel;
		price=pPrice;
		color=pColor;
	}
	
	void info() {
		System.out.println("---휴대폰 정보---");
		System.out.println("모델:"+model);
		System.out.println("가격:"+price);
		System.out.println("색상:"+color);
	}
	
}
