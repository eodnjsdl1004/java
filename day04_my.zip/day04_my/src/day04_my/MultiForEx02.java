package day04_my;

import java.util.Scanner;

public class MultiForEx02 {	
	public static void main(String[] args) {
		//조건이 바뀌는 for문
		
		/*
		 *  * 
		 *  ** 
		 *  *** 
		 *  ****
		 *  *****
		 */
		
		for(int i=0; i<5; i++) {
			for(int j=0; j<i+1;j++) {
				System.out.print("★");				
			}
			System.out.println();
		}
		
		System.out.println("-------------");
		
		/*
		 *  *****
		 *  ****
		 *  *** 
		 *  ** 
		 *  * 
		 */
		System.out.print("별의 수 입력>");
		Scanner sc = new Scanner(System.in);
		int star =sc.nextInt();
		
		for(int i=0; i<star; i++) {
			for(int j=0; j<star-i;j++) {
				System.out.print("★");				
			}
			System.out.println();
		}		
		System.out.println("-------------");
		
		for(int i=0; i<5; i++) {
			for(int j=5; j>i;j--) {
				System.out.print("★");				
			}
			System.out.println();
		}		
		System.out.println("-------------");
		
		for(int i=0; i<star; i++) {
			
			for(int j=0; j<star-1-i;j++) {//" "
				System.out.print("   ");
			}
			for(int k=0; k<=i+i;k++) {//"★"
				System.out.print("★");	
			}			
			System.out.println();			
		}
		System.out.println("-------------");
		
		System.out.println("마름모  홀수 입력>");
		int dia =sc.nextInt();
				
		for (int i=0;i<dia;i++){
		  for (int j=0; j<dia;j++)
		  {
		     if (i<=dia/2)// 위쪽 영역
		     {
		        if (i+j<dia/2)// 왼쪽 위 공백찍기
		           System.out.print("   "); // 공백이 *는 1칸, ★는 3칸
		        else if (j-i>dia/2) // 오른쪽 위 공백찍기
		        	System.out.print("   ");
		        else
		           System.out.print("★");// *찍기
		     }
		     else if (i>dia/2) //아래쪽 영역
		     {
		        if (i-j>dia/2) //왼쪽 밑 공백
		        	System.out.print("   ");
		        else if (i+j>dia/2*3)//오른쪽 밑 공백
		        	System.out.print("   ");
		        else
		        	System.out.print("★"); // *찍기
		     }
		  }
		  System.out.println();//줄바꿈
		}
		sc.close();
	}
}
