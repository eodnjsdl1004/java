package day04_my;

import java.util.Scanner;

public class ForEx02 {

	public static void main(String[] args) {
		//정수를 받아서 해당 정수가 소수인지 판별.
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수입력>");
		int num = scan.nextInt();
		int cnt = 0;
		
		for(int i=1; i<=num; i++) {
			if(num%i==0) 
				cnt++; // 카운트하는 변수
			
		}
		
		System.out.println(cnt == 2 ? num+"는 소수입니다.":num+"는 소수가 아닙니다.");
			
		scan.close();		
	}
}
