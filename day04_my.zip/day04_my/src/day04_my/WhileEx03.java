package day04_my;

import java.util.Scanner;

public class WhileEx03 {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		int sum=0;
		int num=0;
		
		int i=1;
		while(i<=10) {
		
			System.out.print("정수입력>");
			num = sc.nextInt();
			sum+=num;
			i++;
		}
		System.out.println("입력받은수:"+sum);
		
		sc.close();
	}
}
