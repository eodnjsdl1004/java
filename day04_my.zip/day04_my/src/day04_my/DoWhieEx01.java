package day04_my;

public class DoWhieEx01 {
	public static void main(String[] args) {

		int k=1;
		int som=0;
		while(k<=10) {
			System.out.println(k);
			som+=k;
			k++;
		}
		System.out.println(som);
		System.out.println("--------------------");
		//결과가 참이면 똑같다.
		
		int i=1;
		int sum = 0;
		do {
			sum+=i;
			
			System.out.println(i);
			i++;
		} while(i<=0); // 거짓이어도 한번은 실행~
		System.out.println("1~10까지의 합: "+sum);		
		
	}
}
