package day04_my;

public class ForEx01 {

	public static void main(String[] args) {
//		for(int j =1; j<=10; j+=2) {
//			
//			System.out.println("히히");			
//		}
		
		
		for(int i=10; i>=1; i--) 
			System.out.println(i);
		
			
		
		
	}
}
