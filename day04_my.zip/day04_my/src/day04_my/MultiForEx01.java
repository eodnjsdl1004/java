package day04_my;

public class MultiForEx01 {
	public static void main(String[] args) {
		
//		for(int i=1; i<=9; i++) {
//			for(int j=1; j<=9; j++) {
//				System.out.println(i+" "+j);
//			}
//		}
		
		for(int i=1; i<=9; i++) {
			for(int j=1; j<=i; j++) {
				System.out.println(i+" "+j);
			}
		}
		
//		int[] arr = new int[5];
//		
//		for(int i=0; i<arr.length; i++) {
//			System.out.println(i);
//			System.out.println("----------");
//			for(int j=i+1; j<arr.length; j++) {
//				System.out.print(j+" ");
//			}
//			System.out.println();
//			System.out.println("------------");
//		}

		
		
	}
}
