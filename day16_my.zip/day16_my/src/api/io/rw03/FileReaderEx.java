package api.io.rw03;

import java.io.FileReader;
import java.io.Reader;

public class FileReaderEx {

	public static void main(String[] args) {
		/*
		 * 문자기반으로 읽어들이는 클래스는 FileReader 클래스입니다.
		 */
		
		Reader reader = null;
		
		try {
			reader = new FileReader("D:\\Course\\Java\\file\\test.txt");
			while(true) {
				int data=reader.read(); //문자를 하나씩 읽어들임
				System.out.print((char)data); //문자형으로 변환
				if(data==-1) break; //읽어들일 문자가 없다면 -1을 반환
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (Exception e2) {

			}
		}
	}
}
