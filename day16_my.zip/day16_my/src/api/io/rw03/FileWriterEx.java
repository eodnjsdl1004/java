package api.io.rw03;

import java.io.FileWriter;
import java.io.Writer;
public class FileWriterEx {
	public static void main(String[] args) {
		/*
		 * 문자를 써서 저장할때 사용하는 클래스는 FileWriter 클래스
		 * 기본적으로 2바이트 단위로 처리하기 때문에 문자 띄어쓰기에 적합합니다.
		 */
		Writer writer = null;
		try {
			writer =new FileWriter("D:\\Course\\Java\\file\\test.txt");
			String str = "오늘은 4월 20일 입니다.\r\n배가 고파요";
			writer.write(str);
			System.out.println("저장되었습니다.");		
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				writer.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		
	}
}
