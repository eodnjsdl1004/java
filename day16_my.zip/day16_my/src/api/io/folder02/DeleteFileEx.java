package api.io.folder02;

import java.io.File;

public class DeleteFileEx {

	public static void main(String[] args) {
		
		try {
			File file = new File("D:\\Course\\Java\\file_test");
			if(file.exists()) {
				if(file.delete()) // 성공시  true 실패시 false 반환
				System.out.println("삭제되었습니다.");
			}else {
				System.out.println("존재하지 않는 파일입니다.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
