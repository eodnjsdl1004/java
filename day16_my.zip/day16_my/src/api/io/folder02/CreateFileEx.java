package api.io.folder02;

import java.io.File;

public class CreateFileEx {
	/*
	 * 자바에서 외부 경로로 폴더를 생성할 때는 File 클래스를 사용합니다.
	 * 생성자에 매개변수로 폴더를 생성할 (경로+폴더명)을 지정합니다.
	 */
	public static void main(String[] args) {
		try {
			File file = new File("D:\\Course\\Java\\file_test");
			
			if(!file.exists()){//존재하면은 true, 존재하지 않으면 false
				file.mkdir(); // 파일 생성
				System.out.println("폴더생성완료");
			}else {
				System.out.println("이미 존재하는 폴더입니다.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
