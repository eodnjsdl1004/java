package api.io.buffered04;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Writer;
import java.util.Scanner;

public class BufferedWriteEx {
	public static void main(String[] args) {
		
		Writer fw = null;
		BufferedWriter bw = null;
		Scanner sc = new Scanner(System.in);
		
		try {
			/*
			 * 순서대로 nextLine()을 써서 두문장을 입력받습니다.
			 * 줄바꿈 처리를 한 다음에 file 폴더 안에 test3.txt형식으로 파일을 쓰세요.
			 */
			
			System.out.print("문장 입력>");
			String str1 = sc.nextLine();
			System.out.print("한 문장 더 입력>");
			String str2 = sc.nextLine();
			
			fw =  new FileWriter("D:\\Course\\Java\\file\\test3.txt");
			bw = new BufferedWriter(fw);
			
			bw.write(str1+"\r\n"+str2);
			System.out.println("정상 입력 ");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				bw.close();
				fw.close();
				sc.close();
			} catch (Exception e2) {
				
			}
		}
	}
}
