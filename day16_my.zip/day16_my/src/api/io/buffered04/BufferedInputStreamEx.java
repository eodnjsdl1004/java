package api.io.buffered04;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;

public class BufferedInputStreamEx {

	public static void main(String[] args) {
		
		/*
		 * Buffered가 붙은 클래스는 입출력 속도 향상을 위한 클래스이며 InputStream은 바이트 기반입니다.
		 */
		
		InputStream fis = null;
		BufferedInputStream bis = null;
		
		try {
			fis = new FileInputStream("D:\\Course\\Java\\file\\test2.txt");
			bis = new BufferedInputStream(fis);
			
			while(true) {
				int data = bis.read();
				System.out.print((char)data); //영문이 아니면 깨진다
				if(data==-1) break;
			}			
		} catch (Exception e) {
			
		} finally {
			try {
				bis.close();
				fis.close();
			} catch (Exception e2) {
 
			}
		}
	}
}
