package api.io.buffered04;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Scanner;

public class BufferedOutputStreamEx {

	public static void main(String[] args) {
		/*
		 * Buffered기 붙은 클래스는 입출력 속도향상을 위한 클래스이며 OutputStream은 바이트 기반입니다.
		 * 
		 * Buffered가 붙은 클래스들은 생성자의 매개변수로 바이트 기반 클래스를 받을 수 있습니다.
		 */
		Scanner sc = new Scanner(System.in);
		OutputStream fos = null;
		BufferedOutputStream bos = null;
		
		try {
			fos = new FileOutputStream("D:\\Course\\Java\\file\\test2.txt");
			bos = new BufferedOutputStream(fos);
			
			System.out.println("문장을 입력하세요");			
			String str = sc.nextLine();
			
//			byte[] bs = str.getBytes();
			bos.write(str.getBytes()); // Write()메서드는 매개변수로 바이트 배열을 받습니다.
			//bos.flush();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				bos.close(); //flush() 닫는 작업을 먼저 해주어야한다.
				fos.close();
				sc.close();
			} catch (Exception e2) {

			}
		}

	}
}
