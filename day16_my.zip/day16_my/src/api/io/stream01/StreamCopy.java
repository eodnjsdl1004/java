package api.io.stream01;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

public class StreamCopy {

	public static void main(String[] args) {
		
		InputStream oldFile = null;
		OutputStream newFile = null; 
		Scanner sc = new Scanner(System.in);
		
		try {
			System.out.print("저장할 파일명>");
			String name=sc.next();
			oldFile = new FileInputStream("D:\\Course\\Java\\worksapce\\day16_my\\src\\api\\io\\stream01\\img.jpg");
			newFile = new FileOutputStream("D:\\Course\\Java\\file\\"+name+".jpg");			
			
			byte[] bs = new byte[100];
			/*
			while(true) {
				int data=oldFile.read(bs);
				if(data==-1)break;				
				newFile.write(bs, 0, data); //byte단위로 읽어오는데 읽어들인 길이가 data이므로 data만큼씩만 읽는다는 뜻				
			}
			*/
			int data;
			while((data=oldFile.read(bs))!=-1) {
				newFile.write(bs,0,data);
			}
			
			System.out.println("복사가 완료되었습니다.");
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				oldFile.close();
				newFile.close();
			} catch (Exception e2) {
				
			}
		}
		
	}
}
