package api.io.stream01;

import java.io.FileInputStream;
import java.io.InputStream;

public class InputStreamEx {

	public static void main(String[] args) {
		
		/*
		 * 1. 파일을 읽어들이는데 사용하는 클래스는 FileInputStream입니다.
		 * 2. 생성자의 매개값으로 읽어들일 파일의 전체 경로를 적습니다.
		 * 3. io패키지의 모든 메서드 throws 키워드가 있기 때문에 try-catch안에서 사용합니다.
		 */
		
		InputStream fis = null;
		
		try {
			fis = new FileInputStream("D:\\Course\\Java\\file\\daewon.txt");
			/*
			while(true) {
				
				//영어가 1바이트라서 안깨지는데 한글은 2바이트라 깨짐
				int data=fis.read(); // 1byte 단위로 읽음
				if(data==-1) break; // read메서드가 더이상 읽을 값이 없다면 -1을 반환 
				System.out.print((char)data); // 문자열로 출력
			}
			*/
			byte[] bs = new byte[100]; //100바이트 단위로 읽는다.
			int data = fis.read(bs);
//			System.out.println(Arrays.toString(bs)); //\r이 \n에 포함되어있음 13번이 10번이랑 같이 나옴
			int i=0;
			while(bs[i]!=0) {								
				System.out.print((char)bs[i]);			
				i++;
			}		
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				fis.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}
}
