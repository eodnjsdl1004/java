package api.io.stream01;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;

public class OutputStreamEx {

	public static void main(String[] args) {
		/*
		 * 1. 파일을 쓸때 사용하는 클래스는 FileOutputStream입니다.
		 * 2. 생성자 매개값으로 파일을 쓸 전체경로를 지정합니다.
		 * 3. io패키지 모든 클래스들은 생성자에 throws 키워드가 있기 때문에
		 * 	  try-catch블록과 함께 써야합니다.
		 * 
		 */
		Scanner sc = new Scanner(System.in);
		System.out.print("파일명>");
		String name = sc.next();
		
		OutputStream fos = null;
		try {
			fos = new FileOutputStream("D:\\Course\\Java\\file\\"+name+".txt"); // 경로를 지정
			sc.nextLine(); // next() 다음에 nextLine()을 쓰려고 하면 엔터값기준으로 입력받기 때문에 남아있는 엔터값을 잡아줘야함.
			System.out.println("문장을 입력하세요");
			String str = sc.nextLine(); 
			byte[] bs = str.getBytes(); // 문자열 데이터를 바이트 데이터로 변형
			
			fos.write(bs);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fos.close();	
			} catch (Exception e2) {
				e2.printStackTrace();
			}			
		}
		sc.close();	
	}
}
