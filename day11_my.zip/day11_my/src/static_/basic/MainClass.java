package static_.basic;

public class MainClass {

	public static void main(String[] args) {
		/*
		 * 1.녹색, 빨강 계산기를 각각 생성
		 * 2.계산기 색상을 확인하세요.
		 * 3.add(int a)메서드를 추가
		 * 4.계산기의 result값을 각각 확인
		 * 5.pi와 circle()을 사용해서 원의 넓이를 구하세요.
		 * 
		 */
		
		Calculator c1 = new Calculator();
		c1.setColor("녹색");
		System.out.println("c1 색:"+c1.getColor());
		
		Calculator c2 = new Calculator();
		c2.setColor("빨강");
		System.out.println("c2 색:"+c2.getColor());
		
		c1.add(3);
		System.out.println("c1 값:"+c1.getResult());
		
		c2.add(5);
		System.out.println("c2 값:"+c2.getResult());
		
		double result = 3*3*Calculator.pi;
		System.out.println(result);
		System.out.println(Calculator.circle(3));
	
		System.out.println("----------------------");
		
		int[] iArr = {1,2,3,4,5,6,7,8,9,10};
		System.out.println(ArrayPrint.printArray(iArr));
	}
}
