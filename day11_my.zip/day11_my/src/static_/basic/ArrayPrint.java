package static_.basic;

public class ArrayPrint {
	
	//1. 외부에서 객체를 생성할 수 없도록 접근제한자를 붙이세요.
	//2. 객체를 생성하지 않고 메서드를 사용하도록 static을 붙이세요.
	
	private ArrayPrint() {
		
	}

	public static String printArray(int[] iArr){	
		String s="";
		for(int i=0; i<iArr.length; i++) 
			s+= i==0?"["+iArr[i]:i==iArr.length-1? ", "+iArr[i]+"]":", "+iArr[i];
			return s;
	}
	
	public static String printArray(String[] sArr){	
		String s="";
		for(int i=0; i<sArr.length; i++) 
			s+= i==0?"["+sArr[i]:i==sArr.length-1? ", "+sArr[i]+"]":", "+sArr[i];
		return s;
	}
	
	public static String printArray(char[] cArr){
		String s="";
		for(int i=0; i<cArr.length; i++) 
			s+= i==0?"["+cArr[i]:i==cArr.length-1? ", "+cArr[i]+"]":", "+cArr[i];
			return s;
	}
	
}
