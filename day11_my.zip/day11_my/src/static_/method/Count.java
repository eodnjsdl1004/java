package static_.method;

public class Count {

	public int a;
	public static int b;
	//정적 변수는 클래스 외부에 따로 만들어진다.

	//일반 메서드 - 일반멤버변수, 정적멤버변수 모두 사용이 가능.
	public int method1() {

		a=10;
		return ++b;		
	}

	//정적 메서드 - static 메서드안에서는 일반멤버변수를 사용할수없고 정적 멤버변수만 사용이 가능
	//단, 객체생성을 통해서는 일반변수의 사용이 가능.
	//정적 메서드는 클래스 외부에 따로 만들어진다.
	public static int method2() {
		
		Count c = new Count();
		
		c.a=10;
		
		return ++b;
	}
}
