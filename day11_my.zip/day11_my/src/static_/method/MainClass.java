package static_.method;

public class MainClass {

	public static void main(String[] args) {
		
		Count.b++;
		//static메서드 사용
		Count.method2();
		Count.method2();
		
		Count c = new Count();
		
		c.a = 10;
		c.method1();
		System.out.println(Count.b);
		
//		Math.random(); //static 메서드
//		String.valueOf("c"); //static 메서드
//		Integer.parseInt("3");
//		Calendar.getInstance();
		
		
		
	}
}
