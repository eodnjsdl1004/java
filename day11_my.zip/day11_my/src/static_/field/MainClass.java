package static_.field;

public class MainClass {

	public static void main(String[] args) {
		//static 변수 b는 값을 공유하기 때문에 객체가 다르더라도 같은값을 갖는다.
		
		/*
		 * static은 클래스 밖에 1개 생성된다.
		 * 객체생성없이 클래스이름.변수명으로 사용할수 있습니다. 
		 */
		Count c1 = new Count();		
		
		c1.a++;
		Count.b++;//객체를 만들지 않아도 클래스 이름. static 변수명으로 접근가능
		
		System.out.println("일반멤버변수:"+c1.a);
		System.out.println("일반멤버변수:"+Count.b);
		
		Count c2 = new Count();
		
		c2.a++;
		Count.b++;//객체를 만들지 않아도 클래스 이름. static 변수명으로 접근가능
		
		System.out.println("일반멤버변수:"+c2.a);
		System.out.println("일반멤버변수:"+Count.b);
		
		Count.b++;
		Count.b = 100;
		
		System.out.println(c1.b);
		System.out.println(c2.b);
		System.out.println(Count.b);
		
		System.out.println(Math.PI);		
	}
}
