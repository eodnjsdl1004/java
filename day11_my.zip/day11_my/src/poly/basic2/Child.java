package poly.basic2;

public class Child extends Parent {

	//오버라이딩
	public void Method2() {
		System.out.println("자식의 재정의된 2번 메서드 실행");
	}
	public void Method3() {
		System.out.println("자식의 3번 메서드 실행");
	}
}
