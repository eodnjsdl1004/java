package poly.basic2;

public class MainClass {

	public static void main(String[] args) {
		Parent p = new Parent();
		p.Method1();
		p.Method2();
		
		Child c = new Child();
		c.Method1(); //상속받은 메서드
		c.Method2(); //오버라이딩된 메서드
		c.Method3(); //자식 고유의 메서드
		
		System.out.println("-------------------");
		
		Parent p1 = c;
		
		System.out.println(c); //주소값
		System.out.println(p1); //주소값
		System.out.println(p1==c); //주소값 동일 
		
		//주소값이같기때문에 오버라이딩된 c의 메서드가 실행된다.
		//그러나 Parent형으로 형변환이 되어서 자식 고유의 메서드는 쓸수가 없게 된다.
		
		p1.Method1(); //부모 고유의 메서드
		p1.Method2(); //오버라이딩된 메서드
		
		/*
		 * 다형성 적용시에 자식이 가지고 있던 원래 멤버와 접근 할 수 없는 문제가 발생합니다.
		 * 단, 재정의 된 메서드는 정상적으로 호출 됩니다.
		 */
		
		System.out.println("------------------------");
		
		Parent pp =  new Child(); //부모타입에 저장된 자식 클래스 객체였기 때문에
		Child cc = (Child)pp; //강제 형변환이 됨
		
		/*
		 * 다형성이 일어나지 않은 객체를 대상으로 클래스캐스팅의 실행화면
		 * 에러가 발생합니다.
		 */
		
		//에러발생
		//Parent ppp = new Parent();
		//Child ccc=(Child)ppp;
		
	}
}
