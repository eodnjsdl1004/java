package poly.basic3;

public class Person extends Object {
	String name;
	int age;
	
	Person(String name, int age){
		super();//생략되어있다.
		this.name=name;
		this.age=age;
//		System.out.println(this);
	}
	
	Person(String name){
//		this.name=name;
//		this.age=1;
//		System.out.println(this);
		this(name,1);
		
	}
	
	Person(){
//		this.name ="이름 x";
//		this.age =1;
//		System.out.println(this);
		this("이름x",1);
	}
	
	String info() {
		return "이름:"+name+", 나이:"+age;
	}
}
