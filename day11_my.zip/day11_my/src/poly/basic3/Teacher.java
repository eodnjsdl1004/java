package poly.basic3;

public class Teacher extends Person {

	String subject; //과목
	
	Teacher(String name, int age, String subject){
		super(name,age);
		this.subject=subject;
	}
	
	String info() {
		return super.info()+", 교과목:"+subject;
	}
}
