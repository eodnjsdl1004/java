package poly.basic3;

import java.util.Arrays;

public class House {

//	private Student[] students;
//	private Teacher[] teachers;
//	private Employee[] employees;
//	
//	private int cnt1;
//	private int cnt2;
//	private int cnt3;
//	
//	public House(){
//		students = new Student[100];
//		teachers = new Teacher[100];
//		employees = new Employee[100];
//	}
//	
//	public void setIn(Student s) {
//		students[cnt1] = s;
//		cnt1++;
//	}
//	
//	public void setIn(Teacher t) {
//		teachers[cnt2] = t;
//		cnt2++;
//	}
//	
//	public void setIn(Employee e) {
//		employees[cnt3] = e;
//		cnt3++;
//	}
	
	/*
	 * 1. 300개 크기로 Person 배열 생성
	 * 2. count 변수 선언
	 * 3. setIn() 모든 자식 클래스를 받아서 Person 배열에 저장되되록
	 * 4. 메인 클래스에서 6명의 Person을 전달 
	 */
	
	private Person[] pArr;	
	private int cnt;
	
	public House(){
		pArr = new Person[300];
	}
	
	public void setIn(Person p) {
		pArr[cnt]=p;
		cnt++;
		System.out.println(Arrays.toString(pArr));
	}	
	
	
	
}
