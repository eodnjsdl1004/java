package Constant;

public class MainClass {

	public static void main(String[] args) {
		System.out.println(Const.EARTH_RADIUS);
		System.out.println(Const.PI);
		System.out.println(Const.O2);
		
		System.out.println(Math.PI);
		System.out.println(Integer.BYTES);
	}
}
