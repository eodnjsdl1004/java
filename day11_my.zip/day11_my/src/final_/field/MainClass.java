package final_.field;

public class MainClass {

	public static void main(String[] args) {
		
		Person p1 = new Person("123123","박한국");
		
//		p1.nation="미국"; // final변수는 값을 바꿀수 없음
//		p1.ssn="123456";
//		p1.name="박마이클";
		
		System.out.println("국가:"+p1.nation);
		System.out.println("주민번호:"+p1.ssn);
		System.out.println("이름:"+p1.name);
		
		Person p2 = new Person("456456","김종국");
	}
}
