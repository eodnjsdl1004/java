package final_.method;
//static 다음이 final

public /*final상속이 안됨*/ class Parent {

	public void method1() {}	
	public final void method2() {}
	
}
