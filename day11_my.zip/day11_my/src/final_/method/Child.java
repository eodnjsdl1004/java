package final_.method;

public class Child extends Parent {

	public void method1() {
		/*super.*/method2();//사용은 가능하다
	}
	
	//public void method2() {} 오버라이딩이 안됨
}
