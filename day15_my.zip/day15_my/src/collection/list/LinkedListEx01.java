package collection.list;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class LinkedListEx01 {

	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<>(); //Queue 와 List 둘다 사용
		List<String> list2 = new LinkedList<>(); // List 사용
		Queue<String> list3 = new LinkedList<>(); // Queue 사용
		
		//추가
		list.add("홍길동");
		list.add("홍길자");
		list.add("김길동");
		
		//확인
		System.out.println(list.toString());
		
		//처음인덱스에 추가
		list.addFirst("팽귄");
		
		//마지막인덱스에 추가
		list.addLast("팽수");		
		System.out.println(list.toString());
		
		//값 확인
		System.out.println("0번째 인덱스값"+list.get(0));		
		//삭제 
		list.remove(3);
		System.out.println(list.toString());
	}
}

