package collection.list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class ArrayListEx01 {

	public static void main(String[] args) {
		//ArrayList 객체 생성
		ArrayList<Integer> leest = new ArrayList<>(); // 제네릭 클래스이므로 <>를 붙인다.!!!!		
		List<String> list = new ArrayList<>(); // List 부모에도 저장할수 있다!!!!
//		Collection<Double> least = new ArrayList<>(); // Collection 부모에도 저장할수 있다!!!! 하지만 이렇게  사용하면 기능이 떨어진다.
		
		//List에 추가 add()
		list.add("JAVA");
		list.add("JSP");
		list.add("DB");
		list.add("SPRING");
		list.add("JAVA");
		
		//List의 크기 size()
		System.out.println("list의 크기:"+list.size());
		
		//list에 저장된 형태를 문자열로 확인 toString()
		System.out.println(list.toString());
		
		//list에 중간에 추가 add(index, 값)
		list.add(2, "ORACLE");
		System.out.println(list.toString());
		
		//list에 값을 수정 set(index,값)
		list.set(2, "MYSQL");
		System.out.println(list.toString());
		
		//list안에 값 얻기 get(index)
		String value = list.get(2);
		System.out.println(value);
		
		//list의 포함여부 contains(값)
		if(list.contains("JSP")) //JSP가 있다면 true, 없다면 false
			System.out.println("JSP가 포함되어있음");	
		
		//list의 삭제 remove(값), remove(인덱스)
		list.remove(0);
		System.out.println(list.toString());
		list.remove("JSP");
		System.out.println(list.toString());
		
		/////////////////////////////////////////////////////////////////////////////////////
		
		List<String> list2 = new ArrayList<>();
		list2.add("홍길동");
		list2.add("홍길순");

		list.addAll(list2); //list에 컬렉션을 전체 추가
		System.out.println(list.toString());
		
		/////////////////////////////////////////////////////////////////////////////////////
		
		String[] arr = {"이순신","신사임당"};		
		List<String> list3 = Arrays.asList(arr);
		
		list.addAll(list3); //list에 컬렉션을 전체 추가
		System.out.println(list.toString());		
	}
}
