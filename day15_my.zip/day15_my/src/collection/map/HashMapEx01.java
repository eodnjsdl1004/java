package collection.map;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapEx01 {

	public static void main(String[] args) {
		
		//HashMap 객체 생성
		//HashMap<Integer, String> map= new HashMap<>();
		Map<Integer, String> map= new HashMap<>();
		
		//map에 저장 map.put(key, value);
		map.put(1, "홍길동");
		map.put(2,"이순신");
		map.put(3,"홍길자");
		map.put(4,"신사임당");
		
		System.out.println("맵의 크기"+map.size());
		System.out.println("맵의 정보"+map.toString());
		
		//맵에 같은 key를 넣었을 경우, 추가하지 않고 key에 대한 value를 수정합니다.
		map.put(3, "김유신");
		System.out.println(map.toString());
		String s = map.get(3);
		System.out.println("3번 키에 저장된 값"+s);
		
		//map에 저장된 값을 순서대로 출력하려면 keySet, entrySet를 사용
		Set<Integer> keyset = map.keySet(); // key만 뽑아서 set으로 변경해주는 기능
		System.out.println(keyset.toString());
		
		for(Integer i : keyset) {
			System.out.println(map.get(i));
		}
		System.out.println("-----------------------------------");
		
		//keySet에 저장된 값을 순서대로 출력하려면 Iterator로 바꿔 저장, 반복자 사용
		Iterator<Integer> iter = keyset.iterator();		
		while(iter.hasNext()) {
			System.out.println(map.get(iter.next()));
		}
		
		System.out.println("-----------------------------------");
		//keySet에 저장된 값을 List로 변경해서 출력
		List<Integer> list = new ArrayList<Integer>(keyset);
		for(int i=0; i<list.size(); i++) {
			map.get(list.get(i));
		}
		
		//entryset에는 저장된 키와 값 객체(Entry)로 같이 저장해준다.
		Set<Entry<Integer, String>> entryset = map.entrySet();		
		
		for(Entry<Integer, String> e:entryset) {
			System.out.println(e.getKey()+":"+e.getValue());		
		}
		
		//map에 있는 key 유무 확인
		if(map.containsKey(1)) {
			System.out.println("1번키 값"+map.get(1));
		}
		
		//map의 데이터 삭제 remove(key)
		map.remove(2);
		System.out.println(map.toString());
	}
}

