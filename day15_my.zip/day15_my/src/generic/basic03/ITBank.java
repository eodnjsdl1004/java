package generic.basic03;

public class ITBank{
	//Course<?> - ?는 뭐든 다 들어갈수 있다.
	//Course<? extends Student> Student의 자식 클래스는 다 들어갈 수 있다.
	//Course<? super Student> Student의 형태라면 다 들어갈 수 있다.

	public Course<Student> get() {
		Course<Student> c = new Course<>();
		c.setNum("2");
		c.setStudent( new Student("홍길순",30) );
		return c;
	}
	 // 직접 지정방식 <타입을 직접 지정해준다.>
	 //<?>를 쓰면 다 받을수있다.
	
	// <? extends Student> Student의 자식을 받을수 있다 
	//자기 자신의 객체와 상속을 통한 자기 하위 객체들
	
	//<? super Student> 스튜던트형으로 캐스팅되는 모든 타입을 매개변수로 받는다.
	//자기 자신과 상속을 통한 상위 객체들
	
	public void info(Course<Student> c) {
		String num = c.getNum();
		
		Student student = c.getStudent();
		System.out.println("번호:"+num+", 이름:"+student.getName()+", 나이:"+student.getAge());
	}
}
