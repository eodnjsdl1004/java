package generic.basic03;

public class MainClass {

	public static void main(String[] args) {
		Course<Student> course = new Course<>();
		
		course.setNum("1");
		course.setStudent(new Student("홍길동",20));
		 
		ITBank kg = new ITBank();
		kg.info(course);
		
		System.out.println(kg.get().getNum());
		System.out.println(kg.get().getStudent().getName());
		System.out.println(kg.get().getStudent().getAge());
	}
}
