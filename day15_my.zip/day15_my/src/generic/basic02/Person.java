package generic.basic02;

public class Person {

}
