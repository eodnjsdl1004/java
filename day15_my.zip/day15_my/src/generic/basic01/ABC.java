package generic.basic01;

public class ABC<T> { // 제네릭은 클래스의 매개변수입니다.
	
	private T t;

	public T getT() {
		return t;
	}

	public void setT(T t) {
		this.t = t;
	}
}
