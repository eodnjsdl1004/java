package generic.basic01;

public class MainClass {

	public static void main(String[] args) {
		
		//generic을 사용하면, 객체로 생성할때 사용할 타입을 지정할 수 있고,
		//다양한 값을 저장하도록 생성할 수 있습니다.
		
		ABC<String> abc = new ABC<>(); //생성자의 타입은 생략이 가능.
		
		abc.setT("홍길동");
		String name = abc.getT();
		System.out.println(name);
		
		ABC<Integer> def = new ABC<>(); // 제네릭에는 기본형타입은 들어갈수 없고 클래스 타입(Wrapper클래스)이 들어갈수 있다.
		
		def.setT(321);
		int num = def.getT();
		System.out.println(num);
		
		
		ABC<Person> ghi = new ABC<>();
		
		ghi.setT(new Person());
		Person p=ghi.getT();
		
		System.out.println(p);		
		
	}
}
