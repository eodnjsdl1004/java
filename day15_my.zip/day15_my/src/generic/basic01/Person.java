package generic.basic01;

public class Person {

}
