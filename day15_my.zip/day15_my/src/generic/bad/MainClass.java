package generic.bad;

public class MainClass {

	public static void main(String[] args) {
		ABC abc = new ABC();
		
		abc.setObj("홍길자");		
		String name = (String)abc.getObj(); // 사용시 캐스팅을 해줘야하는 문제점이 있다.
		System.out.println(name);
		
		ABC def = new ABC();
		
		def.setObj(new Person());
		Person p = (Person)def.getObj();
		//Object 형으로 선언하면 무엇이든 저장할 수 있지만, 반대로 저장했던 값을 사용할때
		//타입 별로 형변환을 해야하는 문제가 발생.
		//잘못 형변환 한다면 예외를 발생시킵니다.
		System.out.println(p);
		
	}
}
