package day02_my;

public class IntegerEx {

	public static void main(String[] args) {
		byte a = 127;
		byte b = -128;
		
		short c = 32767;
		short d = -32768;
		
		int e = 2147483647;
		int f = -2147483648;
		
		long g = 123123123123123123L;
		System.out.println(g);
		
		/*
		 * 2진수를 저장할때는 0b를 붙임
		 * 8진수를 저장할때는 0을 붙임
		 * 16진수를 저장할때 0x를 붙임
		 */
		
		int bin = 0b1010;
		System.out.println("2진수 1010:"+bin+"입니다.");
		
		System.out.println("-------------------------------");
		
		float f1 = 3.14f;
		double d1 = 3.14;
		
		System.out.println(f1);
		System.out.println(d1);
		
		float f2 = 3.14159265358f;
		double d2 = 3.14159265358;
		

		System.out.println(f2);
		System.out.println(d2);
		
		float f3 = 314.15e-2f;
		double d3 = 0.0031415e3; //e는 10의 지수승을 해준다.
		

		System.out.println(f3);
		System.out.println(d3);
		
		System.out.println("----------------------");
		
		boolean bool1 = true;
		boolean bool2 = false;
		
		System.out.println(bool1);
		System.out.println(bool2);
		
	}
}
