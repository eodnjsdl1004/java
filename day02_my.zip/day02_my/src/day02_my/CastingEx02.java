package day02_my;

public class CastingEx02 {

	public static void main(String[] args) {
		
		/*
		 * 크기가 큰타입을 작은  타입에 변환할때는 (Type) 캐스팅을 이용해서
		 * 명시적 형변환을 해야합니다.
		 */
		
		int i = 70;
		char c = (char)i;
		short s = (short)i;
		
		float f = 3.14f;
		int j = (int)f;
		int k = (int)f;
		
		System.out.println(c);
		System.out.println(s);
		System.out.println(j);
		System.out.println(k);
		
		/*
		 * 강제타입변환시 주의할점은 해당값을 받을 수 없는 범위가 들어오면
		 * 잘려나간 값(쓰레기값)을 저장합니다.
		 */
		
		int a = 1000;
		byte b = (byte)a;
		System.out.println(b);
		
		
		/*
		 * char형을 short형으로 바꿀때도 같은 2byte여도 명시적 형변환이 필요합니다.
		 */
		
		char cc = 'A';
		short ss = (short)cc;
		
		short sss = 65;
		char ccc = (char)sss;
	}
}
