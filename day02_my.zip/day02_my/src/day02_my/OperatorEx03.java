package day02_my;

public class OperatorEx03 {

	public static void main(String[] args) {
		
		int x = 10,y = 20;
		//if 뒤에 소괄호가 true이면 if 중괄호 실행, false라면 else 중괄호 실행
		if(x != 10 && ++y == 21) { // &&일 경우(두개짜리 연산자일경우) 앞에가  false라면 뒤를 실행하지 않음
				System.out.println("참 입니다.");
		}else {
			System.out.println("거짓 입니다.");
		}
		System.out.println("x값:"+x);
		System.out.println("y값:"+y);
		
		if(x == 10 || ++y == 21) {// ||일 경우(두개짜리 연산자일경우) 앞에가 true라면 뒤를 실행하지 않음
				System.out.println("참 입니다.");
		}else {
			System.out.println("거짓 입니다.");
		}
		System.out.println("x값:"+x);
		System.out.println("y값:"+y);
	}
}
