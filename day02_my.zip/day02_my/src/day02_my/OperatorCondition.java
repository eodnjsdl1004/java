package day02_my;

public class OperatorCondition {

	public static void main(String[] args) {
		
		//random한 실수(double)값을 발생시키는 기능(0.0이상 ~1.0미만)
		System.out.println(Math.random());
		//1~10까지의 랜덤값
		double d = Math.random()*10;
		int result = (int)d+1; // 1~10
		System.out.println(d);
		
		int rs = (int)(Math.random()*10)+1;
		System.out.println(rs); //1~10 랜덤값
		
		String s = rs%3 ==0? "3의 배수 입니다.":"3의 배수가 아닙니다.";		
		System.out.println(s);
		
	}
}
