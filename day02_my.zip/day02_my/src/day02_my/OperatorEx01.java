package day02_my;

public class OperatorEx01 {

	public static void main(String[] args) {
		//단항 연산자
		
		//부호 연산자 +,-		
		int i = -3;
		int j = -i;
		
		//증감 연산자 ++,--
		int k = 1;
		int l = k++; //후위 연산자 먼저값을 대입후에 증가한다.
		System.out.println("k값:"+k);
		System.out.println("l값:"+l);
		
		int x = 1;
		int y = ++x; // 전위 연산자 먼저값을 증가한후에 대입한다.
		System.out.println("x값:" + x );
		System.out.println("y값:" + y);
		
		//일반적인 사용
		x=1;
		x++;
		++x;
		
		System.out.println("x:"+x);
		System.out.println("--------------------------------");
		x=1;
		y=1;
		System.out.println(x++); //1
		System.out.println(++x); //3
		
		x=10;
		y=10;
		
		int result = x++ + ++y + 10; 
		System.out.println(result); //31

		//예외
		x=10;
		y=10;
	
		int result1 = x++ + x++ + x++; // 10 + 11+ 12
		
		System.out.println(result1); // 33
		
		System.out.println("--------------------------");
		
		//비트 연산자~
		byte b = 10; //0000 1010
		System.out.println(~b+1); //1111 0101 => - 000001011=> -11 +1 => = -10
		
		System.out.println("-------------------------");
		
		//논리 반전 연산자 ! - 반대의 의미
		System.out.println(!true); //f
		System.out.println(!false); //t
		
		boolean bool = ! true;
		System.out.println(!bool);
	
	}
}
