package day03_my;

import java.util.Scanner;

public class SwitchEx01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("0~3까지 숫자 입력>");
		int a=sc.nextInt();
		//switch구문의 소괄호 안에는 변수나, 변수의 연산식 -> 값이 들어감.
		switch(a) {
		
		case 0:
		case 1:
			System.out.println("1입니다.");
			break;
		case 2:
			System.out.println("2입니다.");
			break;
		case 3:
			System.out.println("3입니다.");
			break;
		default: System.out.println("1~3이 아닙니다.");
		
		}
		sc.close();
	}
}
