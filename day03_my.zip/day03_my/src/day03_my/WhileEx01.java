package day03_my;

public class WhileEx01 {

	public static void main(String[] args) {
		
		
		int a = 1; // 제어 변수: 반복문의 횟수를 제어할 변수
		int sum = 0; //  반복문 밖에다가  선언해줘야함.
		
		while(a<=10) { //조건식
			System.out.println(a);
			sum+=a;
			a++; // 반복문이 언젠가는  false가 되도록 처리
		}
		System.out.println(sum);
		System.out.println(a);
	}
}
