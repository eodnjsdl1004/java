package day03_my;

import java.util.Scanner;

public class WhileEx02 {

	public static void main(String[] args) {
		
		//입력받은 수가 소수 인지  판별하는 코드. 소수(1과 자기자신으로만 나누어 떨어지는 수)
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수입력>");
		int num = sc.nextInt();
		
		int i =2;
		while(num%i!=0) {
			
			i++;
		}
		System.out.println(num==i?num+ "는 소수": num + "은 소수가 아님");
	}
}
