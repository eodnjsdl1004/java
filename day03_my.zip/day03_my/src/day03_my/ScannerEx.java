package day03_my;

import java.util.Scanner;

public class ScannerEx {

	public static void main(String[] args) {
		
		//1. Scanner 생성		
		Scanner scan = new Scanner(System.in); // import 해주어야함.
		
		//2. Scanner가 가지고 있는 입력 기능을 통해서 데이터를 입력받음
		System.out.print("이름>");
		String name = scan.next(); //공백 허용x
		
		System.out.print("나이>");
		int age = scan.nextInt(); //정수
		
		System.out.print("키>");
		double cm = scan.nextDouble(); //실수

		System.out.print("자기소개>");
		scan.nextLine(); // 엔터값을 기준으로 값을 받아들임 
		//앞에서 scanner를 사용하여 엔터를 쳤을 경우, nextLine을 사용하려면 남아있는 엔터값을 제거해주는 작업을 해야함
		String intro = scan.nextLine(); //공백 허용o,
		
		System.out.println("이름:"+name+", 나이:"+age+", 키:"+cm);
		System.out.println("자기소개:"+intro);
		
		//스캐너 작업 반납
		scan.close(); // 닫는 작업을 해야한다.
	}
}
