package api.lang.sb;

public class StringBufferEx {

	public static void main(String[] args) {
		String str = new String("Java");
		System.out.println(str);
		
		StringBuffer sb = new StringBuffer("Java");
		System.out.println(sb);
		
		str = str+" program"; //값을 변경하려면 새로운 객체가 생성됨.		
		sb.append(" program"); //값을 추가하였지만 객체를 재사용함.
		
		System.out.println(str);
		System.out.println(sb);
		
		//문자열 추가 append
		sb.append(" study");
		
		//문자열 추가 insert
		sb.insert(12, "ming");
		System.out.println(sb);
		
		//문자열 변경 replace
		sb.replace(5, 16, "book");		
		System.out.println(sb);
		
		//문자열 delete
		sb.delete(5, 10);
		System.out.println(sb);
		
		//(뒤집기) 문자열을 거꾸로 reverse
		System.out.println(sb.reverse());
	}
}
