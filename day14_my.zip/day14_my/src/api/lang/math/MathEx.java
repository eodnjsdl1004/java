package api.lang.math;

public class MathEx {

	public static void main(String[] args) {
		
		
		double d = Math.random();
		System.out.println(d);
		
		double d1=Math.ceil(1.1);
		System.out.println(d1); //올림
		
		double d2=Math.floor(1.5); //내림
		System.out.println(d2);
		
		double d3 = Math.round(1.5); //반올림
		
		int max = Math.max(1, 2); //큰수
		System.out.println(max);
		
	}
}
