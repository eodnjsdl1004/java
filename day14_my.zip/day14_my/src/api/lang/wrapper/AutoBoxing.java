package api.lang.wrapper;

public class AutoBoxing {

	public static void main(String[] args) {
		
		//autoboxing 기본타입을 자동으로 객체형으로 반환
		Integer var1 = 100;
		Double var2 = 3.14;
		
		//autounboxing 객체형을 기본타입으로 자동으로 변환
		int a = var1;
		double b = var2;
		
		System.out.println(var1+" "+a);
		System.out.println(var2+" "+b);
		
		//오토박싱이후에 wrapper클래스는 문자열을 기본형으로 변환하는데 많이 사용됩니다.(Parse+기본타입으로)
		int v1 = Integer.parseInt("3");
		double v2 = Double.parseDouble("3.14");
		long v3 = Long.parseLong("10");
		
		System.out.println(v1+v2+v3);
		
		System.out.println(Integer.BYTES+" "+Integer.MAX_VALUE);
	}
}
