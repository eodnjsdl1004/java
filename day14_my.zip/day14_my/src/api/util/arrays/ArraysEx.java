package api.util.arrays;

import java.util.Arrays;

public class ArraysEx {

	public static void main(String[] args) {
		
		int[] arr= {1, 2, 3, 4, 5, 6, 7};
		
		//배열의 정렬
		Arrays.sort(arr);
		
		//배열의 검색(선행조건: 오름차순 정렬이 되있어야 함.)		
		int index = Arrays.binarySearch(arr, 5);
		System.out.println("5가 있는 위치"+index);
		
		index = Arrays.binarySearch(arr, -2);
		System.out.println("10이 있는 위치"+index);
		
		//배열의 복사 copyof
		int[] copyArr=Arrays.copyOf(arr, arr.length); // 배열이름, 배열의 길이
		
		//배열의 문자열 확인
		System.out.println(Arrays.toString(copyArr));
		
		//배열의 복사2 범위 선택 
		copyArr=Arrays.copyOfRange(arr, 2, 5);
		System.out.println(Arrays.toString(copyArr));
		
		arr.equals(copyArr);//주소를 보는 equals
		
		//배열의 내부요소가 동일한지 확인
		if(Arrays.equals(arr, copyArr))
			System.out.println(true);
		else 
			System.out.println(false);
		
		//배열을 리스트로
		System.out.println(Arrays.asList(arr));
		
		
	}
}
