package api.util.calendar;

import java.util.Calendar; //싱글톤의 대표적인 클래스

public class CalendarEx {

	public static void main(String[] args) {
		//Calendar cal = new Calendar();싱글톤이라 생성이 안됨
		
		Calendar cal=Calendar.getInstance(); //달력 관련 클래스 싱글톤형식
		
		int year=cal.get(Calendar.YEAR);
		int month=cal.get(Calendar.MONTH)+1;
		int date=cal.get(Calendar.DATE);
		
		System.out.println(year+"년"+month+"월"+date+"일");
		
		int hour=cal.get(Calendar.HOUR);
		int minute=cal.get(Calendar.MINUTE);
		int second=cal.get(Calendar.SECOND);
		
		System.out.println(hour+"시"+minute+"분"+second+"초");
	}
}
