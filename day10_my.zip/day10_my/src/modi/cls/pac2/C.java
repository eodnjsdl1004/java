package modi.cls.pac2;

import modi.cls.pac1.*;

public class C {

	//default와 public의 차이 같은 패키지 내에서만 사용가능한지
	//A a= new A();
	B b= new B();
}
