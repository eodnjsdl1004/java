package modi.cls.pac1;

public class B {

	//default 클래스- 같은 패키지에서 사용이 가능 멤버변수
	A a=new A();
}
