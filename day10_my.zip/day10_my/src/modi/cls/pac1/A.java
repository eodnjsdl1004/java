package modi.cls.pac1;

//클래스에는 public과 default밖에 없다.
//default 접근제한자를 붙이지 않는 형태 - 같은 패키지에서만 접근을 허용 
class A {

}
