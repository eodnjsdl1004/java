package modi.constructor.pac2;

import modi.constructor.pac1.A;

public class C {

	A a1=new A(1); // public 가능
	//A a2=new A(false); // default 불가능 다른 패키지면 사용 안됨
	//A a3=new A("hi"); // private 불가능 같은 패키지여도 클래스 밖을 벗어나지 못함.
	
}
