package modi.constructor.pac1;

public class A {
	
	//멤버변수
	A a1=new A(1);
	A a2=new A(true);
	A a3=new A("hi");
	
	public A(int i){}
	
	//default
	A(boolean b){}
	
	private A(String s){}

}
