package modi.constructor.pac1;

public class B {
	
	A a1=new A(1); // public 가능
	A a2=new A(true); // default 가능
	//A a3=new A("hi"); // private 불가능 같은 패키지여도 클래스 밖을 벗어나지 못함.

}
