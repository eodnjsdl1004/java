package modi.member.pac1;

public class A {
	
	public int var1;
	int var2;
	private int var3;

	public void method1() {}
	void method2() {}
	private void method3() {}
	
	//생성자
	//같은  클래스 같은 패키지 안이라서 전부 사용가능함.
	public A() {
		var1=1;
		var2=1;
		var3=1;
		
		method1();
		method2();
		method3();
	}
}
