package encap.good;

import java.util.Arrays;

public class MainClass {

	public static void main(String[] args) {
		MyDate me = new MyDate();
		
		//멤버변수를 private으로 선언하면 접근할수 없음
//		me.year = -2020;
//		me.month = 13;
//		me.day = 100;
//		me.ssn = "이게 뭐죠?";
		
		me.setYear(1995);
		int year = me.getYear();
		System.out.println(year+"년");
		
		me.setMonth(3);
		int month = me.getMonth();
		System.out.println(month+"월");	
		
		me.setDay(18);
		int day = me.getDay();
		System.out.println(day+"일");
		
		me.setSsn("950318xxxxxxx");
		String ssn = me.getSsn();
		System.out.println(ssn);
		
		me.info();		
		
		System.out.println("--------------------");
		
		
		Member m1 = new Member("팽귄", "멋잇어", "대원", "이메일123", "경기", 123456, 3);
		Member m2 = new Member("팽귄", "멋잇어", "대원", "이메일123", "경기", 123456, 3);
		
		Member[] mArr = new Member[2];
		
		mArr[0]=m1;
		mArr[1]=m2;
		
		//주소값을 참조하고 있다.
		System.out.println(Arrays.toString(mArr)); 
		
		for(int i=0; i<mArr.length; i++) {
			Member m = mArr[i];
			
			System.out.println(m.getId());
			System.out.println(m.getPw());
			System.out.println(m.getName());
		}		
		
		for(Member m: mArr) {
			System.out.println(m.getEmail());
			System.out.println(m.getPhone());
			System.out.println(m.getAge());
		}
		
		
		
	}
}

