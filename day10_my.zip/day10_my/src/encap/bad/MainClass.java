package encap.bad;

public class MainClass {

	public static void main(String[] args) {
		MyDate me = new MyDate();
		
		//멤버변수를 public으로 선언하면 잘못된 저장방법으로 접근할수 있음
		me.year = -2020;
		me.month = 13;
		me.day = 100;
		me.ssn = "이게 뭐죠?";
		
		me.info();
	}
}
