package exception.myexception;

public class MyException extends Exception{

	private static final long serialVersionUID = 1L;
	
	MyException(){
		super("잔액 부족");
	}
	
	MyException(String message){
		super(message);
	}

}
