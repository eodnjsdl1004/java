package exception.myexception;

public class MainClass {
	
	public static void main(String[] args) {
		
		Account account = new Account();
		
		account.depostit(30000L);
		
		try {
			account.withdraw(20000L);
			account.withdraw(20000L);		
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println(account.getBalance());
	}
}
