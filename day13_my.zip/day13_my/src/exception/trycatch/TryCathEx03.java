package exception.trycatch;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryCathEx03 {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print(">");
			try {
				int num = sc.nextInt();
				
			} catch (InputMismatchException e) {
				System.out.println("숫자로 입력해주세요.");
				sc.nextLine();//Scanner 클래스의 남아있는 엔터값을 받아줌.				
			}
		}		
	}
}
