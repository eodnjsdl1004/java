package exception.trycatch;

public class RuntimeEx {

	public static void main(String[] args) {
		
		//ArrayIndexError		
//		int[] arr= {1,2,3,4,5};
//		System.out.println(arr[5]);		
		
		//ClassCast		
//		String s = (String)new Object();
		
		//NumberFormat
//		String s ="야호";		
//		int i = Integer.parseInt(s);		
//		System.out.println(i);
		
		//Nullpointer
		String s = null;
		s.charAt(0);
		
	}
}
