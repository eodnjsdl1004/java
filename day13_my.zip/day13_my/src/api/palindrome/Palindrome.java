package api.palindrome;

public class Palindrome {

	/*
	 * 아이티뱅크 친구 네오는 palindrome() 함수를 만들었습니다.
	 * -매개변수를 String 값을 받아서 회문 여부를 검사하는 메서드입니다.
	 * 회문 ex "다시 합창 합시다" "아 좋다 좋아" "다시다"
	 * 
	 * 매개변수를 공백 포함해서 받을수 있습니다.
	 * 회문이라면 return 회문입니다.를 반환합니다.
	 * 회문이 아니라면 "회문이 아닙니다."를 반환합니다.
	 */
	public static String palindrome(String s) {

		String str=s.replace(" ","");
		int cnt=0;
		for(int i=0; i<str.length(); i++) {
			if(str.charAt(i)==str.charAt(str.length()-1-i))
				cnt++;
		}
		if(cnt==str.length())
			return "회문입니다.";
		else
			return "회문이 아닙니다.";
	}
}
