package api.lang.string;

import java.util.Arrays;

public class StringEx {

	public static void main(String[] args) {
		
		//charAt - 문자열 인덱스번호 자르기
		String str ="안녕하세요~";
		
		char a=str.charAt(1);
		System.out.println(a);
		
		//IndexOf - 문자열을 찾아서 인덱스를 반환
		int i=str.indexOf("~");
		System.out.println(i);
		
		//length - 문자열의 길이를 정수형으로 반환 
		System.out.println("문자열의 길이 "+str.length());
		
		//replace - 특정문자열의 변경
		String str2="자바는 재밌습니다. 자바는 커피집 이름입니다.";		
		String result=str2.replace("자바", "java");
		System.out.println(result);		
		System.out.println(str2);
		
		//공백제거
		result=result.replace(" ", "");
		System.out.println(result);
		
		//substring - 문자열 자르기
		String str3 = "123123-4564564";
		System.out.println(str3.substring(7)); //매개값을 한개 주면 앞문자열을 제거
		System.out.println(str3.substring(0, 6));//잘라서 가져올 부분 선택 0~6까지 가져옴
		System.out.println(str3.substring(7, str3.length())); //문자열을 2개주면 문자열을 추출
		
		//trim - 앞뒤 공백제거
		String str4 ="    홍길동    ";
		str4=str4.trim();
		System.out.println(str4);
		
		//format - 형식지정한 대로 나타내는 법
		System.out.println(String.format("%.2f", 3.141592));
		
		//valueOf - 기본형을 문자열로 변환
		System.out.println(String.valueOf(3)+String.valueOf(4));
		
		//split - 문자열 자르기
		String str5 = "010-1234-5678";
		String[] arr = str5.split("");
		System.out.println(Arrays.toString(arr));		
		String[] arr2 = str5.split("-",2);  //반환되는 배열의 길이 제한
		System.out.println(Arrays.toString(arr2));
	}
}
