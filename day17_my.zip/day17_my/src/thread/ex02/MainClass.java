package thread.ex02;

public class MainClass {

	public static void main(String[] args) {
		ThreadTest t = new ThreadTest();
		
		Thread thread1 = new Thread(t,"A");
		Thread thread2 = new Thread(t,"B");
		
		thread1.start();
		thread2.start();

	}

}

