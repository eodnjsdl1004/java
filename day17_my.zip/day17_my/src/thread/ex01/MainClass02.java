package thread.ex01;

public class MainClass02 {

	public static void main(String[] args) {
		ThreadTest t1 = new ThreadTest();
		
		Thread thread1 = new Thread(t1,"A");
		Thread thread2 = new Thread(t1,"B");
		
		thread1.start();
		thread2.start();
		
		System.out.println("메인종료~");
		
	}
}
