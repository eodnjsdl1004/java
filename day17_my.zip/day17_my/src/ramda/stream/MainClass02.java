package ramda.stream;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class MainClass02 {
	public static void main(String[] args) {
		
		List<Integer> list = new ArrayList<>();
				
		Person s = new Student();
		Person t = new Teacher();
		
		for(int i=0; i<100; i++) {			
			list.add(new Random().nextInt(100)+1);			
		}
		System.out.println(list.toString());	
		
		//중복제거 stream 반환 distinct();
		list.stream().distinct().forEach((num)-> System.out.print(num+" "));
		System.out.println();
		
		//조건에 맞는 식에 따라서 true false를 통해 값을 걸러낸뒤 stream 반환의 filter();
		list.stream().filter((num) -> num%2==0).forEach((num)->System.out.print(num+" "));
		System.out.println();
		
		//정렬  stream 반환 sorted()
		list.stream().distinct().sorted().forEach((num)->System.out.print(num+" "));
		System.out.println();
		
		//map은 키값으로 매개값을 받고 돌려줄때는 다른 값으로 변경가능
		list.stream().distinct().sorted().map((num)-> num%2==0? s: t).forEach((str)->System.out.print(str+" "));
		
		System.out.println();
		List<Person> li =list.stream().distinct().sorted().map((num)-> num%2==0? s: t).collect(Collectors.toList());		 
		
		System.out.println(li.size());
		for(int i=0; i<li.size(); i++) {
			if(li.get(i) instanceof Student) {
				Student student = (Student)li.get(i);
				String str =i+"2020";
				student.setStuId(str);
				student.info();				
			} else if(li.get(i) instanceof Teacher)
				System.out.println("선생님입니다.");
		}
		
		
		System.out.println();
		List<String> l =list.stream().distinct().filter((num) -> num%2==0).sorted().map((num)-> num%2==0? "짝수": "홀수").collect(Collectors.toList());
		l.forEach((str)->System.out.print(str+" "));
		//list의 중복을 제거하고 짝수만 찾아낸다음 정렬하고 
		//짝홀수로 변경한 결과를 List반환 받고 Foreach 구문으로 처리
		
		
	}
}
