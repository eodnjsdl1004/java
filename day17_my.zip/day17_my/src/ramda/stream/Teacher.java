package ramda.stream;

public class Teacher extends Person {

}
