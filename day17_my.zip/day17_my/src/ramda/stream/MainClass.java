package ramda.stream;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class MainClass {

	public static void main(String[] args) {
		
		
		List<String> list= new ArrayList<>();
		
		list.add("홍길동");
		list.add("홍길자");
		list.add("홍길순");
		list.add("펭귄");
		list.add("이순신");
		
//		for(String s:list) {
//			System.out.println(s);
//		}
		
//		Iterator<String> iter = list.iterator();		
//		for(;iter.hasNext();) {
//			System.out.println(iter.next());
//		}
		
		Stream<String> stream = list.stream();
		//forEach메서드는 Stream for문처럼 회전하는 기능
		//함수적 인터페이스로 되어있기때문에 매개변수로 람다식의 표현을 쓸수 있다.
		stream.forEach((s) -> System.out.println(s)	); //한줄이면 중괄호 생략가능
		
				
	}
}
