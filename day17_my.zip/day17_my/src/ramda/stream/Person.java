package ramda.stream;

public class Person {

}
