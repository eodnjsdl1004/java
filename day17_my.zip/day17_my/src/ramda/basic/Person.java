package ramda.basic;

public class Person {
	
	public void greeting(Say01 say) {
		System.out.println("1");
		say.talking();
	}
	
	public void greeting(Say02 say) {		
		System.out.println("2");
		System.out.println(say.talking());
	}
	
	public void greeting(Say03 say) {
		System.out.println("3");
		System.out.println(say.talking("peng-hi"));
	}
	
	public String greeting(Say04 say) {
		System.out.println("4");
		return say.talking("hi",3);
	}
}
