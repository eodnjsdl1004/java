package ramda.basic;

public interface Say04 {

	public String talking(String word, int i);
}
