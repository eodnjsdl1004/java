package ramda.basic;

public interface Say02 {

	public String talking();
}
