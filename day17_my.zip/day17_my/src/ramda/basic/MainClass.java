package ramda.basic;

public class MainClass {

	public static void main(String[] args) {
		Person p = new Person();
		
		p.greeting(new Say01() {			
			@Override
			public void talking() {
				System.out.println("말합니다.");
			}
		});		
		
		p.greeting(new Say02() {			
			@Override
			public String talking() {
				return "펭하";
			}
		});
		
		p.greeting(new Say03() {
			
			@Override
			public String talking(String greet) {				
				return greet;
			}
		});
		
		
		System.out.println("--------");
		//익명객체 Say01이 구현해야할 추상메서드를 람다식으로 표현
		p.greeting(()-> {			
			System.out.println("안녕");		
		});		
		
		p.greeting(()-> {			
			return "끼룩";		
		});
		
		//greet라는 매개변수를 say03형식에 맞춰 적어줘야한다. 타입은 생략가능
		p.greeting((greet)-> {			
			return "peng-hi";		
		});
		
		//greeting 메서드를 실행해서 결과로 HiHiHi를 반환받는 람다 표현식 사용
		String result = p.greeting((String word, int i)->{
			String str="";
			for(int j=0; j<i; j++)
			str+=word;
			
			return str;
		});
		System.out.println(result);
	}
}
