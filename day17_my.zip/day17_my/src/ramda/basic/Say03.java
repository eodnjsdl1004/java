package ramda.basic;

public interface Say03 {
	
	public String talking(String greet);
}
