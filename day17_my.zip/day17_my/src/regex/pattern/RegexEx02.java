package regex.pattern;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexEx02 {

	public static void main(String[] args) {

		/*
		 * 많이 쓰이는 형식
		 * \\w 영문자 숫자 찾음
		 * \\w+ 영문자 숫자  여러개 
		 * 
		 * \\d 숫자 찾음
		 * \\d 숫자 여러개
		 * 
		 * \\d{3} 숫자 3개를 찾음
		 * \\d{3,4} 숫자3개  or 숫자4개
		 * 
		 * {0-9}0~9사이의 문자 1개를 찾음
		 * {A-Z}A~Z사이의 문자 1개를 찾음
		 * {a-z}a~z사이의 문자 1개를 찾음
		 * {가-힗}한글1개를 찾음
		 * {가-힗}한글1개를 찾음
		 */

		String info ="30세/서울시 강남구/02-123-4567/010-2345-6789/kkk@naver.com";

		String pattern =  "\\d{2,3}-\\d{3,4}-\\d{4}";
		String pattern2 =  "\\w+@\\w+.\\w+";

		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(info);		

		
		Matcher m2 = Pattern.compile(pattern2).matcher(info);
		
		while(m.find()){//info문자열에서 정규표현 패턴을 찾아서 true, false로 반환
			System.out.println(m.start()); //찾은 시작 인덱스번호 return
			System.out.println(m.end()); //찾은 끝 인덱스번호 return
			System.out.println(m.group()); // 찾은 값 return
		}		
		
		while(m2.find()) {
			System.out.println(m2.start());
			System.out.println(m2.end());
			System.out.println(m2.group());
		}
		
	}
}
