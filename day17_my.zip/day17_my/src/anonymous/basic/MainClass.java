package anonymous.basic;

public class MainClass {

	public static void main(String[] args) {
		
		Garage gar = new Garage();
		gar.tico.run();
		gar.matiz.run();
		
		
		
	}
}
