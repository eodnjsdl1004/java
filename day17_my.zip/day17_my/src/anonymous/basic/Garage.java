package anonymous.basic;


interface Car{
	public void run();
}

class Tico implements Car{

	@Override
	public void run() {		
		System.out.println("티코가 달립니다.");
	}	
}

public class Garage {
	
	//멤버변수 
//	public Car car = new Tico(); //원래 사용해야하는것은 객체를 생성해야하는데
	//내부클래스를 만들어 쓸수 있음
	
	public Car tico = new Tico();
	
	public Car matiz = new Car() {
		
		@Override
		public void run() {
			System.out.println("익명객체 마티즈가 달립니다.");			
		}
	};
}
