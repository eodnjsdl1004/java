package anonymous.basic2;

public class Tv {

	private int volume;
	private RemoteControl remote;
	
	
	
	public Tv(){
		//remote타입을 Tv에 맞게 끔 초기화 하기
		remote = new RemoteControl() {
			
			@Override
			public void volumUp() {
				volume++;
				System.out.println("익명객체 Tv 볼륨:"+volume);
			}
			
			@Override
			public void volumDown() {
				volume--;
				System.out.println("익명객체 Tv 볼륨:"+volume);				
			}
			
			@Override
			public void turnon() {
				System.out.println("익명객체 Tv 전원을 켭니다.");					
			}
			
			@Override
			public void turnoff() {
				System.out.println("익명객체 Tv 전원을 끕니다.");				
			}
		};
		
		
	}
	
	//getter, setter
	public RemoteControl getRemote() {		
		return remote;
	}
	
	public void setRemote(RemoteControl remote) {
		this.remote = remote;
	}
	
	
}
