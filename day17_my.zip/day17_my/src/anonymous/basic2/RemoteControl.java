package anonymous.basic2;

public interface RemoteControl {

	public void turnon(); // 켜다
	public void turnoff(); // 끄다
	public void volumUp(); // 소리를 높이다.
	public void volumDown(); // 소리를 낮추다.
}

