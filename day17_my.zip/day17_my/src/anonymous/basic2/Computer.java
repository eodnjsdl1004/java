package anonymous.basic2;

public class Computer {

	private int sound;
	private RemoteControl remote;
	
	//생성자
	public Computer() {
		//익명객체
		remote = new RemoteControl() {
			
			@Override
			public void volumUp() {
				sound++;
				System.out.println("익명객체 컴퓨터 볼륨:"+sound);
			}
			
			@Override
			public void volumDown() {
				sound--;
				System.out.println("익명객체 컴퓨터 볼륨:"+sound);
			}
			
			@Override
			public void turnon() {
				System.out.println("익명객체 컴퓨터 전원을 켭니다.");				
			}
			
			@Override
			public void turnoff() {
				System.out.println("익명객체 컴퓨터 전원을 끕니다.");			
			}
		};
	}
	
	//remote의 getter, setter 메서드 생성
	
	public RemoteControl getRemote() {
		return remote;
	}

	public void setRemote(RemoteControl remote) {
		this.remote = remote;
	}
}
