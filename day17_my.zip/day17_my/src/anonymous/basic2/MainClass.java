package anonymous.basic2;

public class MainClass {

	public static void main(String[] args) {
		Computer com = new Computer();
		
		com.getRemote().turnon();
		com.getRemote().volumUp();
		com.getRemote().volumDown();
		com.getRemote().turnoff();	
		
		com.setRemote(new RemoteControl() {			
			@Override
			public void volumUp() {
				System.out.println("익명객체 볼륨업");				
			}			
			@Override
			public void volumDown() {
				System.out.println("익명객체 볼륨다운");				
			}			
			@Override
			public void turnon() {
				System.out.println("익명객체 전원 on");				
			}			
			@Override
			public void turnoff() {
				System.out.println("익명객체 전원 off");							
			}
		});
		System.out.println("---------------------");
		
		Tv tv = new Tv();
		
		tv.getRemote().turnon();
		tv.getRemote().volumUp();
		tv.getRemote().volumDown();
		tv.getRemote().turnoff();
		
		tv.setRemote(com.getRemote());
		
		tv.getRemote().turnon();
		tv.getRemote().volumUp();
		tv.getRemote().volumDown();
		tv.getRemote().turnoff();
		
	}
}
