package day01;

public class IdentifierEx {
	
	
	public static void main(String[] args) {
		int age = 27;
		int Age = 28;
		
		System.out.println(age);	
		System.out.println(Age);
		
//		int phonenumber = 4; ctrl+/ 빠른주석
		int phoneNumber = 10;
		//int phone Number = 20;
		
//		int public 키워드로는 이름을 지을수 없음
//		int class
	}
	
}
