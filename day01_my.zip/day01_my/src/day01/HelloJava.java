package day01;

public class HelloJava {
	public static void main(String[] args) {
		// \n은 줄바꿈 명령문
		System.out.print("Hello Java\n");
		System.out.println("안녕하세요");
		System.out.println(1);
		System.out.print("1");
	}	
}
