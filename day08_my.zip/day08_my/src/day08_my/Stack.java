package day08_my;

public class Stack {

	public static void m1(int a) {
		m2(++a);	
		System.out.printf("m1():%d\n",a);
	}
	
	public static void m2(int a) {
		m3(++a);	
		System.out.printf("m1():%d\n",a);
	}
	
	public static void m3(int a) {
		++a;	
		System.out.printf("m1():%d\n",a);
	}
	public static void main(String[] args) {		
		int a=20;
		m1(a);
		System.out.printf("main():%d\n",a);
	}
}
