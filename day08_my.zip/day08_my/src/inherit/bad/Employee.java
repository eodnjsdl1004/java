package inherit.bad;

public class Employee {

	String name;
	int age;
	String department; //부서
	
	String info() {
		return "이름:"+name+", 나이:"+age;
	}
}
