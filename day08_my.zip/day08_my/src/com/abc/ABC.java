package com.abc; // 패키지 선언 자동.

public class ABC {

}
