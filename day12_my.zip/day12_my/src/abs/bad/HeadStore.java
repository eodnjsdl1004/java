package abs.bad;

public class HeadStore {

	public void apple() {
		System.out.println("사과의 가격은 지점에서 정해주세요.");
	}
	
	public void banana() {
		System.out.println("바나나의 가격은 지점에서 정해주세요.");
	}
	
	public void orange() {
		System.out.println("오렌지의 가격은 지점에서 정해주세요.");
	}
	
	public void melon() {
		System.out.println("멜론의 가격은 지점에서 정해주세요.");
	}
	
}
