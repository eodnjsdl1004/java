package abs.bad;

public class SeoulStore extends HeadStore {

	@Override //annotation
	public void apple() {
		System.out.println("서울지점 사과는 500원 입니다.");
	}

	@Override
	public void banana() {
		System.out.println("서울지점 바나나는 600원 입니다.");
	}

	@Override
	public void melon() {
		System.out.println("서울지점 멜론는 700원 입니다.");
	}

	//프로그래머가 오렌지 재정의를 빼먹었다... 가정
}
