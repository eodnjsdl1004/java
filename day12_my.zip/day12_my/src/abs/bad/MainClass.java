package abs.bad;

public class MainClass {

	public static void main(String[] args) {
		SeoulStore s = new SeoulStore();
//		HeadStore s = new SeoulStore();
		
		//재정의를 빼먹는다면, 잘못된 메서드의 실행으로 이어질 수도 있다는 뜻입니다.
		s.apple();
		s.banana();
		s.melon();
		s.orange(); //재정의 된 매서드가 아니라서 제대로 실행이 안됨
	}
}
