package abs.good;

public class SeoulStore extends HeadStore {
	//빨간줄에 마우스 올려서 unimplements method 클릭
	SeoulStore(){
		super();
	}

	@Override
	public void apple() {
		System.out.println("서울지점 사과는 600원 입니다.");
	}

	@Override
	public void banana() {
		System.out.println("서울지점 바나나는 700원 입니다.");
	}

	@Override
	public void orange() {
		System.out.println("서울지점 오렌지는 800원 입니다.");
	}

	@Override
	public void melon() {
		System.out.println("서울지점 멜론은 900원 입니다.");
	}


	
}
