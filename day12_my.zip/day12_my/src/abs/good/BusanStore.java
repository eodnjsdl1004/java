package abs.good;

public class BusanStore extends HeadStore {

	@Override
	public void apple() {
		System.out.println("서울지점 사과는 200원 입니다.");
	}

	@Override
	public void banana() {
		System.out.println("서울지점 바나나는 300원 입니다.");
	}

	@Override
	public void orange() {
		System.out.println("서울지점 오렌지는 400원 입니다.");
	}

	@Override
	public void melon() {
		System.out.println("서울지점 멜론은 500원 입니다.");
	}

}
