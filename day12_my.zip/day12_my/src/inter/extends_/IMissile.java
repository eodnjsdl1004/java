package inter.extends_;

public interface IMissile extends IToy {

	public void canMissaile();
}
