package inter.extends_;

public interface IMove extends IToy {
 
	public void canMove();
}
