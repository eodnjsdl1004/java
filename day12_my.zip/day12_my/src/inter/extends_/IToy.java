package inter.extends_;

public interface IToy {

	public void info();
}
