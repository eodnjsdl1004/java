package inter.extends_;

public class TeddyBear implements IMove{

	@Override
	public void info() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void canMove() {
		// TODO Auto-generated method stub
		
	}

}
