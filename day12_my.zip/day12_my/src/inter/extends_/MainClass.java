package inter.extends_;

public class MainClass {

	public static void main(String[] args) {
		IMissile missile = new Robot();
		
		missile.info();
		missile.canMissaile();
	}
}
