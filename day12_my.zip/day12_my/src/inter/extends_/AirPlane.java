package inter.extends_;

public class AirPlane implements ILight,IMove,IMissile {

	@Override
	public void info() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void canMissaile() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void canMove() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void canLight() {
		// TODO Auto-generated method stub
		
	}

}
