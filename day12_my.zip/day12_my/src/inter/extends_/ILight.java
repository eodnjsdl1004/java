package inter.extends_;

public interface ILight extends IToy{

	public void canLight();
}
