package inter.basic2;

public class MainClass {
	public static void main(String[] args) {
	
		Animal baduk = new Dog();
		Animal nabi = new Cat();
		Animal hodol = new Tiger();
		
		Fish nimo = new GoldFish();
		
		System.out.println("-----Animal기능-----");
		//1. Animal[]을 생성후 baduk, nabi, hodol을 저장한후에 향상된 포문으로 Animal의 공통기능을 출력
		Animal[] animal= {baduk,nabi,hodol};		
		for(Animal a:animal) {			
				a.eat();			
		}
		System.out.println("-----Pet기능-----");
		//2. IPet[] 생성후 baduk, nabi, 금붕어를 저장하고 향상된 포문으로 IPet의 공통 기능을 출력
		//baduk이는 Animal타입이지만, 하위클래스가 상호연관이 있다면, 형변환이 가능
		IPet[] pet = {(Dog) baduk,(IPet) nabi, (IPet)nimo}; 		
		for(IPet p:pet) {			
				p.play();			
		}		
		
		PetHouse p = new PetHouse();
		
		System.out.println("---케어하우스---");
		p.carePet((IPet)baduk);
		p.carePet((IPet)nabi);
		p.carePet(new GoldFish());
		
		System.out.println("---케어하우스---");
		p.petInfo(pet);
		
	}
}
