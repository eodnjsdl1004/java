package inter.basic2;

public class PetHouse {

	/*
	 * 1.carePet() 메서드 선언
	 * 매개변수는 모든 팻타입을 받을 수 있도록 선언
	 * 기능-intanceof를 사용해서 캐스팅을 해보고, "멍멍이를 돌봅니다." 출력문 처리
	 */
	
	public void carePet(IPet p){
		
		if(p instanceof Dog) {
			Dog d = (Dog)p;
			System.out.println("바둑이를 돌봅니다.");
		}
		else if(p instanceof Cat) {
			Cat c = (Cat)p;
			System.out.println("나비를 돌봅니다.");
		}			
		else if(p instanceof GoldFish) {
			GoldFish g = (GoldFish)p;
			System.out.println("니모를 돌봅니다.");
		}
			
	}
	
	/*
	 * 2.petInfo() 메서드 선언
	 * 매개변수는 Ipet배열을 받을 수 있도록 선언
	 * 기능-Ipet배열을 회전해서 play()를 실행
	 */
	
	public void petInfo(IPet[] pet){
		for(int i=0; i<pet.length; i++) {
			pet[i].play();
		}
	}
}
