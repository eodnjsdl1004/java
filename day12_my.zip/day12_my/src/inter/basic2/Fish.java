package inter.basic2;

public abstract class Fish {

	public abstract void swim();
}
