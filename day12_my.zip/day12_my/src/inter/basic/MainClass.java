package inter.basic;

public class MainClass {
	public static void main(String[] args) {
		Basic b=new Basic();
		
		b.method1();
		b.method2();
		b.method3();
		
		System.out.println(Basic.ABC);
		System.out.println(Basic.PI);
		
		
		/*
		 * 인터페이스도 하나의 데이터 타입이 될수 있습니다.
		 * 인터페이스에 객체를 저장했을때, 다형성을 형태로 동일하게 시행
		 */
		
		Inter1 i1=b;
		i1.method1();
		
		Inter2 i2=b;
		i2.method2();//오버라이딩된 메서드를 사용할수 있고 부모의 기능만을 사용할수있다.
		
		//인터페이스
		Basic b1 = (Basic)i1;		
		Basic b2 = (Basic)i2;
		
	}

}
