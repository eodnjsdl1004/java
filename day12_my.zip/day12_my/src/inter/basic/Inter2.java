package inter.basic;

public interface Inter2 {

	int ABC=3;//상수	
	void method2();//추상메서드
}
