package inter.basic;

public interface Inter1 {

	//상수와 추상메서드를 정의합니다.
	double PI=3.14;//인터페이스안에 변수를 선언하면 자동으로 상수로 선언됩니다.	
	public void method1();//메서드를 선언하면 자동으로 추상메서드가 됩니다.
	
	
	public default void method2() { //default키워드는 일반메서드로 선언할수 있습니다.
		
	}
	public default void method3() { //default키워드는 일반메서드로 선언할수 있습니다.

	}
}
