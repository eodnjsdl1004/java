package inter.basic3;

public interface Printed {

	public void turnOn();
	public void turnOff();
	public void Print(String document);
	public void colorPrint(String document, String color);
	public int copy(int n);	
}
