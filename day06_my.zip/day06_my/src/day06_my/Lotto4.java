package day06_my;

import java.util.Arrays;

public class Lotto4 {

	public static void main(String[] args) {
		
		/*
		 * 1. 크기가 6인 배열에 1~45까지 중복되지 않는 랜덤수를 출력해서
		 * 반환하는 lottoNum() 메서드를 생성하세요.
		 * 
		 * 2.lottoRun() 메서드는 1번에서 생성된 로또 번호를 매개변수를 받아서,
		 * 당첨되기 까지 금액을 구하는 매서드입니다.
		 * 
		 * 랜덤한 로또 번호를 무한히 생성해서, 매개변수로 전달받은 번호와 비교해서 
		 * 당첨되기까지 실행된 금액을 반환하세요.
		 * 
		 * 당첨의 조건(순서는 상관없이 같은 번호만 배열에 담겨있다면 됩니다.)
		 */
		
		int[] arr= lottoNum();
		System.out.println(Arrays.toString(arr));		
		long money = lottoRun(arr);
		System.out.println("당첨되기까지 사용한 금액:" + money+"원");
	}
	
	static int[] lottoNum() {
		int[] tto = new int[6];
		
		int index=0;
		lotto: while(true) {
			if(index==6) break;
			int num = (int)(Math.random()*45)+1;
			//중복검사
			for(int i=0; i<index; i++) {
				if(num==tto[i]) 
					continue lotto;
			}
			tto[index] = num;
			index++;
		}				
		Arrays.sort(tto);
		return tto;
	}
	
	static long lottoRun(int[] arr){
		long money=0;	//로또 시도 횟수
		
		while(true) {
			money++; 			
			int tto[]=lottoNum();
			if(Arrays.equals(arr, tto)) // 동일한 값을 가지고 있으면 true 반환
				return money*1000;
			else
				money++;			
		}
	}
}