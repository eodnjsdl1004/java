package day06_my;

public class MethodEx03 {

	public static void main(String[] args) {
		/*
		 * 반환유형(return type)
		 * 1. 반환유형은 매서드가 실행한 결과를 돌려주는 값에 대한 type입니다.
		 * 2. 반환유형이 있는 메서드는 호출 구문이 하나의 값이 되기 떄문에 다른 메서드의 매개값을 사용합니다.
		 * ex) println(메서드 호출)
		 * 3. 반환값이 없는 경우는 반환type 자리에 void라고 적습니다.
		 * 4. 모든 메서드를 return을 만나면 강제 종료 됩니다.
		 *    그렇게 때문에 return아래에 코드를 작성할 수 없습니다.
		 */
		
		int n = add(add(1,2),add(2,3)); // 매서드안에 매서드를 넣어줄수 있다.
		System.out.println("결과:"+n);
		
		//System.out.println(sub(5,2)); //돌아오는 값이 없으므로 출력문안에 넣을 수도 없고
		//int result = sub(5,2);	//변수에 넣을수도 없고  단순히 호출만 할 수 있다.		
		sub(5,2);
		multi();
		noReturn("바보");
		
	}//메인 끝
	
	static int add(int a, int b) {		
		return a+b;
	}
	
	//매개변수 o 반환 유형x인 메서드
	static void sub(int a, int b) {
		System.out.println(a+"-"+b+"="+(a-b));
	}
	
	//매개변수 x 반환 유형x인 메서드
	static void multi() {
		System.out.println("5x3=15");
		return; // return- 값의 반환, 메서드 종료 두가지 기능이 있음
	}
	
	static void noReturn(String s) {
	
		if(s.equals("똑똑이")) {
			System.out.println("똑똑한사람");
			return;
			//int a= 1;//return 뒤에는 의미없게 됨
		}
		System.out.println(s+" 문자열이 아니고 똑똑이를 입력하세요.");
	}
}
