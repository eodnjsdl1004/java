package day06_my;

public class MethodEx05 {
	public static void main(String[] args) {
		
		/*
		 * participant는 마라톤 참가자 명단입니다.
		 * completion는 마라톤 완주자 명단입니다.
		 * 
		 * completion은 participant의 길이보다 -1이 적습니다.
		 * 참가자는 동명인물이 있을 수 있습니다.
		 * 
		 * 어떤 배열이 주어지던간에 마라톤을 완주하지 못한 이름(String)을 찾아내는 메서드를 작성하세요.
		 */
		
		String[] participant = {"홍길동", "홍길자", "이순신", "신사임당", "이순신"};
		String[] completion = {"홍길자","홍길동", "심사임당","이순신"};
		
		System.out.println("완주하지 못한 사람:"+solution(participant,completion));
		
	}
	
	
	static String solution(String[] p, String[] c) {
		String s="";
		int index=-1;
		
		for(int i=0; i<p.length; i++) {
			int cnt=0;
			int count=0;
			for(int j=0; j<c.length; j++) {				
				if(p[i].equals(c[j])) { //비교했을때 일치한 값이 있다면 	
					index=i; //index변수에 해당 i값을 저장					
				}
				if(p[i].equals(p[j])) {	//참가자 명단에 동명이인이 있다면			
					cnt++;					
					if(p[i].equals(c[j])) {//참가자 동명이인 값이 완주자에 존재한다면
						count++;
					}
				}				
				if(cnt!=count) {//참가자 동명이인 숫자와  완주자 동명이인이 다르면
					index=-1; //공백 작업 스킵	
				}				 
			}				
			if(index!=-1) //index번째 해당 값이 완주한사람이므로
			p[index] =""; //공백작업				
		}
		
		
		for(int i=0; i<p.length; i++) {
			if(p[i].equals(""))
					continue;
			else
				s=p[i];
		}				
		return s;
	}
}
