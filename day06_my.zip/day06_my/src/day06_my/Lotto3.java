package day06_my;

//import java.util.ArrayList;
import java.util.Arrays;
//import java.util.List;

public class Lotto3 {
	public static void main(String[] args) {
		
		/*
		 * 1. 크기가 6인 배열에 1~45까지 중복되지 않는 랜덤수를 출력해서
		 * 반환하는 lottoNum() 메서드를 생성하세요.
		 * 
		 * 2.lottoRun() 메서드는 1번에서 생성된 로또 번호를 매개변수를 받아서,
		 * 당첨되기 까지 금액을 구하는 매서드입니다.
		 * 
		 * 랜덤한 로또 번호를 무한히 생성해서, 매개변수로 전달받은 번호와 비교해서 
		 * 당첨되기까지 실행된 금액을 반환하세요.
		 * 
		 * 당첨의 조건(순서는 상관없이 같은 번호만 배열에 담겨있다면 됩니다.)
		 */
		
		int[] arr= lottoNum();
		System.out.println(Arrays.toString(arr));
		long money = lottoRun(arr);
		System.out.println("당첨되기까지 사용한 금액:" + money+"원");		
	}

	static int[] lottoNum() {
		int[] lo = new int [45];
		int[] tto = new int[6];
		int temp=0;
		
		for(int i=0; i<lo.length; i++) // 순차적으로 1~45까지의 숫자를 배열에 대입
			lo[i]=i+1;
		for(int i=0; i<lo.length; i++) {
			int num=(int)(Math.random()*45);//0~44까지 랜덤수			
			//랜덤으로 자리바꾸기
			temp=lo[i];
			lo[i]=lo[num];
			lo[num]=temp;			
		}		
		
		for(int i=0; i<tto.length; i++) {
			tto[i]=lo[i];
		}			
		Arrays.sort(tto);		
		return tto;
	}
	
	static long lottoRun(int[] arr){
		long money=0;	//로또 시도 횟수
		int count=0;
		while(true) {
			money++; 			
			int tto[]=lottoNum();
			
			for(int i=0; i<tto.length; i++) {
				if(arr[i]==tto[i]) 
					count++;
			}
			if(count==6)
				break;
			else 
				count=0;
		}		
		return 1000*money;
	}	
}