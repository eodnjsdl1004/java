package day06_my;

public class MethodEx02 {

	public static void main(String[] args) {
		/*
		 * 매개변수(Parameter
		 * 1. 매개변수는 메서드 호출할때 실행에 필요한 값을 전달하는 매개체입니다.
		 * 2. 매개변수를 몇개 받을지 메서드를 선언할때 결정합니다.
		 * 반환 o 매개변수 o
		 * 매개변수를 쓰고싶지 않다면 비워두면 됩니다.
		 */
		
		System.out.println("1~100까지 합:"+calSum(100));
		System.out.println("1~50까지 합:"+calSum(50));
		
		int n = calSum(10);
		System.out.println("1~10까지 합:"+n);
		
		System.out.println("10~20까지 합:"+calSum2(10,20));
		
		String str = calSum3(1,10,"가");
		System.out.println(str);
		
	}//메인 끝


	static int calSum(int num){	//num은 사용하지 않아도 문제없다
		int sum=0;
		for(int i=1; i<=num; i++) {
			sum+=i;			
		}		
		return sum;
	}
	
	static int calSum2(int start, int end){	//매개변수를 여러개 받고 싶다면 ,로 연결
		int sum=0;
		for(int i=start; i<=end; i++) {
			sum+=i;			
		}		
		return sum;
	}
	static String calSum3(int start, int end, String s) {
		String str="";
		for(int i=start; i<=end; i++) {
			str+=s;			
		}		
		return str;	
	}
	
}