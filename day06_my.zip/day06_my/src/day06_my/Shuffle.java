package day06_my;

import java.util.Arrays;
import java.util.Collections;


public class Shuffle {

	public static void main(String[] args) {
		
		String[] array = {"data1", "data2", "data3", "data4", "data5"};
	
		Collections.shuffle(Arrays.asList(array));
		
		for (String value : array) {
			System.out.print(value + " ");
		}
	}
}
